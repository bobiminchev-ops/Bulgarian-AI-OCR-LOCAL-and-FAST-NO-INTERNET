﻿# BgGPT Local v12 Fast: selects installed backend (CUDA / Vulkan / CPU), zero Vision overhead, 100% local.
param([switch]$Configure)
$ErrorActionPreference='Stop'
$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
$conf=Join-Path $Root 'config.json'
if(-not(Test-Path $conf)){throw 'Missing config.json. Run INSTALL.cmd first.'}
$c=Get-Content -LiteralPath $conf -Raw -Encoding UTF8 | ConvertFrom-Json
$Alias=[string]$c.modelAlias
$Model=[string]$c.model
$Ctx=if(($c.PSObject.Properties.Name -contains 'contextSize') -and ([int]$c.contextSize -ge 2048)){[int]$c.contextSize}else{4096}
$MaxTok=if($Ctx -ge 4096){'1024'}else{'512'}
$Url='http://127.0.0.1:8080'
$Logs=Join-Path $Root 'logs'
New-Item -ItemType Directory -Path $Logs -Force | Out-Null

function Model-Ready {
  try{
    $res=Invoke-RestMethod -Uri "$Url/v1/models" -TimeoutSec 2
    return @($res.data|Where-Object {([string]$_.id).EndsWith($Alias,[StringComparison]::OrdinalIgnoreCase)}).Count -gt 0
  }catch{return $false}
}

function Has-VisionLoaded {
  try{
    $props=Invoke-RestMethod -Uri "$Url/props" -TimeoutSec 2
    if($props.modalities -and ($props.modalities.vision -eq $true)){return $true}
  }catch{}
  try{
    $ids=@(Get-NetTCPConnection -LocalPort 8080 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique)
    foreach($idVal in $ids){
      $p=Get-CimInstance Win32_Process -Filter "ProcessId=$idVal" -ErrorAction SilentlyContinue
      if($p -and ([string]$p.CommandLine).IndexOf('--mmproj',[StringComparison]::OrdinalIgnoreCase) -ge 0){return $true}
    }
  }catch{}
  return $false
}

function Stop-OwnServer {
  $ids=@(Get-NetTCPConnection -LocalPort 8080 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique)
  $allowed=@((Join-Path ([string]$c.runtime) 'llama-server.exe'),(Join-Path ([string]$c.cpuRuntime) 'llama-server.exe'))
  foreach($idVal in $ids){
    $p=Get-CimInstance Win32_Process -Filter "ProcessId=$idVal" -ErrorAction SilentlyContinue
    if(-not $p -or $allowed -notcontains ([string]$p.ExecutablePath) -or ([string]$p.CommandLine).IndexOf($Model,[StringComparison]::OrdinalIgnoreCase) -lt 0){
      throw 'Port 8080 belongs to another server. Stop it before starting BgGPT.'
    }
  }
  foreach($idVal in $ids){Stop-Process -Id $idVal -Force -ErrorAction SilentlyContinue}
  if($ids.Count){Start-Sleep -Seconds 2}
}

function Port-Busy {
  try{
    Invoke-WebRequest -Uri "$Url/health" -UseBasicParsing -TimeoutSec 2 | Out-Null
    return $true
  }catch{return $false}
}

function Start-Backend([string]$path,[bool]$useGPU,[bool]$legacy) {
  $server=Join-Path $path 'llama-server.exe'
  if(-not(Test-Path $server)){throw ('Missing runtime: '+$server)}
  if($legacy){
    $env:GGML_VK_DISABLE_F16='1'
    $env:GGML_VK_DISABLE_ASYNC='1'
  } else {
    Remove-Item Env:GGML_VK_DISABLE_F16 -ErrorAction SilentlyContinue
    Remove-Item Env:GGML_VK_DISABLE_ASYNC -ErrorAction SilentlyContinue
  }
  $offload=if($useGPU){'99'}else{'0'}
  $args='-m "'+$Model+'" --alias "'+$Alias+'" -ngl '+$offload+' -c '+$Ctx+' --host 127.0.0.1 --port 8080'
  if($legacy){$args+=' -fa off'}
  $stdout=Join-Path $Logs 'server-out.log'
  $stderr=Join-Path $Logs 'server-error.log'
  foreach($f in @($stdout,$stderr)){if(Test-Path $f){Remove-Item $f -Force}}
  $proc=Start-Process -FilePath $server -ArgumentList $args -WorkingDirectory $path -WindowStyle Minimized -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru
  for($i=0;$i -lt 75;$i++){
    Start-Sleep -Milliseconds 700
    if(Model-Ready){return $true}
    $proc.Refresh()
    if($proc.HasExited){break}
  }
  if(-not $proc.HasExited){Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue}
  return $false
}

try{
  if(-not (Test-Path $Model)){throw 'Model missing. Run INSTALL.cmd again.'}
  # If a previous slow Vision server (--mmproj) is still running on 8080, replace it with fast mode
  if((Model-Ready) -and (Has-VisionLoaded)){
    Write-Host 'Switching from heavy Vision server to fast BgGPT mode... / Превключване към бърз режим...' -ForegroundColor Yellow
    Stop-OwnServer
  }
  if(-not(Model-Ready)) {
    if(Port-Busy){throw 'Port 8080 belongs to another server. Stop it before starting BgGPT.'}
    Write-Host ('Starting BgGPT ('+$c.backend+', ctx '+$Ctx+') / Стартиране на BgGPT...')
    $isGPU=([string]$c.backend -ne 'cpu')
    $ok=$false
    try{$ok=Start-Backend ([string]$c.runtime) $isGPU ([bool]$c.legacyAmd)}
    catch{Write-Warning ('GPU start failed: '+$_.Exception.Message); if(-not $isGPU){throw}}
    if(-not $ok -and $isGPU) {
      Write-Warning 'GPU runtime failed to start. Trying safe CPU fallback / Опит с CPU.'
      $ok=Start-Backend ([string]$c.cpuRuntime) $false $false
    }
    if(-not $ok){throw ('Server did not become ready; see '+(Join-Path $Logs 'server-error.log'))}
  }
  Write-Host '[OK] Local BgGPT is ready / BgGPT е готов.' -ForegroundColor Green
  Start-Process $Url | Out-Null
  $anything=[string]$c.anything
  if($anything -and (Test-Path $anything)) {
    Start-Process -FilePath $anything | Out-Null
    if($Configure){
      Start-Sleep -Seconds 3
      $pair=@{
        type='llm'; provider='generic-openai';
        GenericOpenAiBasePath='http://127.0.0.1:8080/v1'; GenericOpenAiKey='local-only';
        GenericOpenAiModelPref=$Alias; GenericOpenAiTokenLimit=[string]$Ctx; GenericOpenAiMaxTokens=$MaxTok
      }
      $keys=@('type','provider','GenericOpenAiBasePath','GenericOpenAiKey','GenericOpenAiModelPref','GenericOpenAiTokenLimit','GenericOpenAiMaxTokens')
      $query=($keys | ForEach-Object { $_+'='+[uri]::EscapeDataString([string]$pair[$_]) }) -join '&'
      try{Start-Process ('anythingllm://set-provider?'+$query) | Out-Null}
      catch{Write-Warning 'Open CONFIGURATION-BG-EN.txt to connect AnythingLLM manually.'}
      Write-Host 'Confirm with Use inside AnythingLLM / Потвърдете с Use.' -ForegroundColor Yellow
    }
  }
  Write-Host "Local API / Локален API: $Url/v1"
}catch{
  Write-Host ('ERROR / ГРЕШКА: '+$_.Exception.Message) -ForegroundColor Red
  exit 1
}
