# BgGPT Local — OneClick Universal v12 Final (Variant 1 — Clean & Fast)

**Complete all-in-one Windows installer (zero Python, zero heavy Vision overhead):**
Run `INSTALL.cmd`, select `BG` or `EN`, enter **`YES`**, and click **INSTALL**.

- **Fast on any hardware:** installs only the official INSAIT **BgGPT-Gemma-3-4B-IT-Q6_K.gguf** (3.18 GB, SHA-256 verified) with pinned **llama.cpp b12651** (CUDA / Vulkan / CPU fallback) and **AnythingLLM Desktop**.
- **4096-token context window (`-c 4096`)** for generous document RAG without slowing down text chat.
- **100% local inference** on `http://127.0.0.1:8080`; existing verified model files and AnythingLLM libraries are preserved.
