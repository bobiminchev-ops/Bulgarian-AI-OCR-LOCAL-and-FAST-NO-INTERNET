@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Install-GUI.ps1"
if errorlevel 1 (
  echo.
  echo Installer did not finish successfully. / Instalaciyata ne priklyuchi uspeshno.
  pause
)
endlocal
