@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-BgGPT.ps1" -Configure
if errorlevel 1 pause
endlocal
