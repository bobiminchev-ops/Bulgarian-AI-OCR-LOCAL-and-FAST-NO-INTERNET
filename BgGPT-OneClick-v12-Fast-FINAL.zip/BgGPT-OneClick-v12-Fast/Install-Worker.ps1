﻿# BgGPT Local Universal v12-final - isolated installation worker, per-run status, fractional progress.
# Windows PowerShell 5.1 x64, zero Python, zero heavy Vision mmproj. 100% local inference.
param(
  [ValidateSet('bg','en')][string]$Language='bg',
  [switch]$ForceModel,
  [Parameter(Mandatory=$true)][ValidatePattern('^[0-9a-f]{32}$')][string]$RunId
)
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
$Root=Join-Path $env:LOCALAPPDATA 'BgGPT-Local'
$Dl=Join-Path $Root 'downloads'
$Models=Join-Path $Root 'models'
$Logs=Join-Path $Root 'logs'
$StatusFile=Join-Path $Root ('install-status-'+$RunId+'.json')
$CancelFile=Join-Path $Root ('install-cancel-'+$RunId+'.flag')
$SourceDir=Split-Path -Parent $MyInvocation.MyCommand.Path

$ModelName='BgGPT-Gemma-3-4B-IT-Q6_K.gguf'
$ModelPath=Join-Path $Models $ModelName
$ModelSize=3184198912L
$ModelSha='3480257711e857221154cae13e6ac4bfe23c089214c21cff2ee633ec5063b979'
$ModelUrl='https://huggingface.co/INSAIT-Institute/BgGPT-Gemma-3-4B-IT-GGUF/resolve/main/BgGPT-Gemma-3-4B-IT-Q6_K.gguf'
$Release='https://github.com/ggml-org/llama.cpp/releases/download/b12651/'
$BaseExe='llama-b12651-bin-win-'
$AnythingUrl='https://cdn.anythingllm.com/latest/AnythingLLMDesktop.exe'

$script:Stages=@([double]0,[double]0,[double]0,[double]0)
$script:Labels=@('','','','')
$script:Note=''
$script:Kind='running'
$script:Backend=''
$script:Gpu=''
$script:AnyExe=''
foreach($d in @($Root,$Dl,$Models,$Logs)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
if (Test-Path $CancelFile) { Remove-Item $CancelFile -Force }

function Say([string]$bg,[string]$en) { if ($Language -eq 'bg') {$bg} else {$en} }
function Check-Cancel { if(Test-Path -LiteralPath $CancelFile){ throw 'Cancelled by the user / Отказано от потребителя.' } }

function Publish([string]$note='', [int]$stage=-1, [double]$percentage=-1, [string]$kind='running') {
  if ($stage -ge 0 -and $stage -lt 4 -and $percentage -ge 0) {
    $script:Stages[$stage]=[Math]::Round([Math]::Max(0.0,[Math]::Min(100.0,$percentage)),2)
  }
  if ($note) { $script:Note=$note; if($stage -ge 0 -and $stage -lt 4){$script:Labels[$stage]=$note} }
  $script:Kind=$kind
  $total=[Math]::Round(([double](($script:Stages | Measure-Object -Sum).Sum) / 4.0),2)
  $json=@{ kind=$script:Kind; stage=$stage; progress=@($script:Stages); labels=@($script:Labels);
    total=$total; note=$script:Note; backend=$script:Backend; gpu=$script:Gpu;
    runId=$RunId; date=[DateTime]::UtcNow.ToString('o') } | ConvertTo-Json -Compress -Depth 4
  $bytes=[Text.Encoding]::UTF8.GetBytes($json)
  for($retry=0;$retry -lt 12;$retry++) {
    $stream=$null
    try {
      $stream=[IO.FileStream]::new($StatusFile,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::Write,
        ([IO.FileShare]([int][IO.FileShare]::ReadWrite -bor [int][IO.FileShare]::Delete)))
      $stream.SetLength(0)
      $stream.Write($bytes,0,$bytes.Length)
      $stream.Flush()
      return
    } catch [IO.IOException] {
      if($retry -eq 11){throw}
      Start-Sleep -Milliseconds 60
    } finally {if($stream){$stream.Dispose()}}
  }
}

function Record([string]$message){
  $stamp='['+[DateTime]::Now.ToString('HH:mm:ss')+'] '+$message
  Add-Content -LiteralPath (Join-Path $Logs 'install.log') -Value $stamp -Encoding UTF8
}

function Verified([string]$path,[long]$min,[string]$sha='') {
  if(-not(Test-Path -LiteralPath $path -PathType Leaf)){return $false}
  if((Get-Item -LiteralPath $path).Length -lt $min){return $false}
  if($sha){return ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ieq $sha)}
  return $true
}

function Download([string]$url,[string]$dest,[long]$size,[long]$min,[string]$sha,[int]$stage,[double]$startPct=0,[double]$endPct=100) {
  Check-Cancel
  if(Verified $dest $min $sha){Publish (Say 'Наличен проверен файл' 'Verified file found') $stage $endPct; return}
  $partial=$dest+'.part'
  if(Test-Path -LiteralPath $partial) {
    $probe=$null
    try {
      $probe=[IO.FileStream]::new($partial,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    } catch [IO.IOException] {
      throw (Say 'Файлът се използва от друга инсталация. Затворете предишния инсталатор и опитайте отново, без да триете .part.' 'The partial download is in use by another installer. Close the older installer and retry; do not delete .part.')
    } finally { if($probe){$probe.Dispose()} }
  }
  if(Verified $partial $min $sha){
    Move-Item -LiteralPath $partial -Destination $dest -Force
    Publish (Say 'Възстановено проверено изтегляне' 'Recovered verified download') $stage $endPct
    return
  }
  $curl=Join-Path $env:SystemRoot 'System32\curl.exe'
  if(-not (Test-Path $curl)){throw 'curl.exe is missing. Windows 10/11 with curl.exe is required.'}
  $args=@('--location','--fail','--retry','3','--retry-delay','3','--connect-timeout','30','--silent','--show-error')
  if((Test-Path $partial) -and ((Get-Item $partial).Length -gt 0)){$args+=@('--continue-at','-')}
  $args+=@('--output',('"'+$partial+'"'),('"'+$url+'"'))
  $fileName=[IO.Path]::GetFileName($dest)
  Publish ((Say 'Изтегляне' 'Downloading')+': '+$fileName) $stage $startPct
  Record ('Official download: '+$url)
  $p=Start-Process -FilePath $curl -ArgumentList ($args -join ' ') -PassThru -WindowStyle Hidden
  while(-not $p.HasExited){
    if(Test-Path $CancelFile){Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue; Check-Cancel}
    if(Test-Path $partial){
      $bytes=(Get-Item $partial).Length
      if($size -gt 0){
        $frac=[Math]::Min(0.99,[Math]::Max(0.0,($bytes*1.0)/$size))
        $pct=[Math]::Round(($startPct+$frac*($endPct-$startPct)),2)
        $numeric=if($Language -eq 'bg'){$pct.ToString('N2',[Globalization.CultureInfo]::GetCultureInfo('bg-BG'))}else{$pct.ToString('N2',[Globalization.CultureInfo]::InvariantCulture)}
        Publish (('{0}: {1:N1} / {2:N1} MB ({3}%)' -f (Say 'Изтеглено' 'Downloaded'),($bytes/1MB),($size/1MB),$numeric)) $stage $pct
      } else {
        Publish (('{0}: {1:N1} MB' -f (Say 'Изтеглено' 'Downloaded'),($bytes/1MB))) $stage -1
      }
    }
    Start-Sleep -Milliseconds 350
    $p.Refresh()
  }
  if($p.ExitCode -ne 0){throw ('Download failed / Грешка при изтегляне: '+$fileName+', curl exit '+$p.ExitCode)}
  if(-not(Verified $partial $min $sha)){throw ('Integrity check failed / Грешка при проверка: '+$fileName)}
  Move-Item -LiteralPath $partial -Destination $dest -Force
  Publish (Say 'Проверен файл' 'Verified download') $stage $endPct
}

function Runtime-Ready([string]$path,[string]$backend){
  $server=Join-Path $path 'llama-server.exe'
  $marker=Join-Path $path '.b12651-ready'
  if(-not (Test-Path -LiteralPath $server -PathType Leaf)){return $false}
  if(-not (Test-Path -LiteralPath $marker -PathType Leaf)){return $false}
  if((Get-Content -LiteralPath $marker -Raw).Trim() -ne $backend){return $false}
  if($backend -eq 'cuda' -and -not (Test-Path -LiteralPath (Join-Path $path 'cublas64_12.dll') -PathType Leaf)){return $false}
  return $true
}

function Runtime-Destination([string]$backend){
  $base=Join-Path $Root ('bin-'+$backend+'-b12651-v11')
  if(Runtime-Ready $base $backend){return $base}
  if(Test-Path -LiteralPath $base){
    foreach($candidate in @(Get-ChildItem -LiteralPath $Root -Directory -Filter ('bin-'+$backend+'-b12651-v11-*') | Sort-Object LastWriteTime -Descending)){
      if(Runtime-Ready $candidate.FullName $backend){return $candidate.FullName}
    }
    $base=$base+'-'+$RunId
  }
  return $base
}

function Commit-Runtime([string]$path,[string]$backend){
  if(-not(Test-Path -LiteralPath (Join-Path $path 'llama-server.exe') -PathType Leaf)){throw 'Runtime executable missing.'}
  Set-Content -LiteralPath (Join-Path $path '.b12651-ready') -Value $backend -Encoding ASCII
}

function Unpack([string]$zip,[string]$dest){
  $tmp=$dest+'-unpack-'+$RunId
  if(Test-Path -LiteralPath $dest){throw 'Runtime destination already exists; no files were overwritten.'}
  New-Item -Path $tmp -ItemType Directory -Force | Out-Null
  Expand-Archive -LiteralPath $zip -DestinationPath $tmp -Force
  $server=Get-ChildItem $tmp -Recurse -Filter 'llama-server.exe' -File | Select-Object -First 1
  if(-not $server){throw ('llama-server.exe missing in '+$zip)}
  New-Item -ItemType Directory -Path $dest -Force | Out-Null
  Copy-Item -Path (Join-Path $server.Directory.FullName '*') -Destination $dest -Recurse -Force
  Remove-Item $tmp -Recurse -Force
}

function Find-Anything {
  foreach($path in @(
    (Join-Path $env:LOCALAPPDATA 'Programs\AnythingLLM\AnythingLLM.exe'),
    (Join-Path $env:LOCALAPPDATA 'Programs\AnythingLLM\AnythingLLMDesktop.exe'),
    (Join-Path $env:LOCALAPPDATA 'Programs\anythingllm-desktop\AnythingLLMDesktop.exe'),
    (Join-Path $env:LOCALAPPDATA 'Programs\anythingllm-desktop\AnythingLLM.exe')
  )){if(Test-Path $path -PathType Leaf){return $path}}
  try{
    $uninst=Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue
    foreach($app in @($uninst | Where-Object { $_.DisplayName -like '*AnythingLLM*' -and $_.InstallLocation })){
      foreach($name in @('AnythingLLM.exe','AnythingLLMDesktop.exe')){
        $path=Join-Path ([string]$app.InstallLocation) $name
        if(Test-Path $path -PathType Leaf){return $path}
      }
    }
  }catch{}
  return $null
}

function Create-Shortcuts {
  $desktop=[Environment]::GetFolderPath('DesktopDirectory')
  if(-not $desktop -or -not (Test-Path $desktop)){return}
  $shell=New-Object -ComObject WScript.Shell
  $link=$shell.CreateShortcut((Join-Path $desktop 'BgGPT Local - Start.lnk'))
  $link.TargetPath=(Join-Path $Root 'START.cmd')
  $link.WorkingDirectory=$Root
  $link.Description='BgGPT Local - Bulgarian AI'
  $link.Save()

  # Clean up any leftover Vision/OCR shortcuts from previous tests
  foreach($oldLnk in @('BgGPT Local - Vision.lnk','BgGPT Local - OCR.lnk')){
    $pOld=Join-Path $desktop $oldLnk
    if(Test-Path -LiteralPath $pOld){Remove-Item -LiteralPath $pOld -Force -ErrorAction SilentlyContinue}
  }

}

function Stop-OwnServerIfVision([string]$runtimeDir,[string]$cpuDir,[string]$modelPath){
  $connections=@(Get-NetTCPConnection -LocalPort 8080 -State Listen -ErrorAction SilentlyContinue)
  $ids=@($connections | Select-Object -ExpandProperty OwningProcess -Unique)
  if(-not $ids.Count){return}
  $allowed=@((Join-Path $runtimeDir 'llama-server.exe'),(Join-Path $cpuDir 'llama-server.exe'))
  foreach($idVal in $ids){
    $p=Get-CimInstance Win32_Process -Filter "ProcessId=$idVal" -ErrorAction SilentlyContinue
    if($p -and ($allowed -contains ([string]$p.ExecutablePath)) -and ([string]$p.CommandLine).IndexOf($modelPath,[StringComparison]::OrdinalIgnoreCase) -ge 0){
      if(([string]$p.CommandLine).IndexOf('--mmproj',[StringComparison]::OrdinalIgnoreCase) -ge 0){
        Record ('Stopping old Vision BgGPT server PID '+$idVal+' to restore fast mode.')
        Stop-Process -Id $idVal -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
      }
    }
  }
}

function Verify-LocalText([string]$alias){
  $body=@{
    model=$alias; temperature=0; max_tokens=16;
    messages=@(@{role='user'; content='Reply with OK.'})
  } | ConvertTo-Json -Depth 6 -Compress
  $res=Invoke-RestMethod -Uri 'http://127.0.0.1:8080/v1/chat/completions' -Method Post -ContentType 'application/json' -Body $body -TimeoutSec 60
  $ans=[string]$res.choices[0].message.content
  Record ('Local fast text self-test response: '+$ans)
  if([string]::IsNullOrWhiteSpace($ans)){throw 'Local text self-test returned empty output.'}
}

$installMutex=$null
$mutexOwned=$false
try{
  $installMutex=[Threading.Mutex]::new($false,'Local\BgGPTLocalOneClickInstall')
  try {$mutexOwned=$installMutex.WaitOne(0)} catch [Threading.AbandonedMutexException] {$mutexOwned=$true}
  if(-not $mutexOwned){throw (Say 'Друга инсталация вече работи. Не пускайте второ изтегляне.' 'Another installation is running. Do not start a second download.')}

  # STAGE 1: Hardware & llama.cpp b12651 runtime
  Publish (Say 'Проверка на компютъра' 'Detecting hardware') 0 0
  if (-not [Environment]::Is64BitOperatingSystem -or [Environment]::OSVersion.Version.Major -lt 10){throw 'Windows 10/11 x64 is required.'}
  $cards=@(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | ForEach-Object {[string]$_.Name})
  $script:Gpu=($cards -join '; ')
  if(-not $script:Gpu){$script:Gpu='Unspecified GPU'}
  $script:Backend='cpu'
  $oldAmd=$false
  if(@($cards | Where-Object {$_ -match 'NVIDIA.*(RTX|GTX (10|16|20|30|40|50))|GeForce RTX|RTX \d{4}' }).Count -gt 0){$script:Backend='cuda'}
  elseif(@($cards | Where-Object {$_ -match 'Radeon|AMD|Intel.*Arc'}).Count -gt 0){$script:Backend='vulkan'}
  if($script:Backend -eq 'vulkan' -and $script:Gpu -match 'R9\s*(290|390)|Radeon\s*Pro\s*580'){ $oldAmd=$true }
  Record ('Detected: '+$script:Gpu+' | selected '+$script:Backend)
  Publish (Say ('Открит хардуер: '+$script:Gpu) ('Detected: '+$script:Gpu)) 0 4

  $cpuZip=$BaseExe+'cpu-x64.zip'
  $cpuZipPath=Join-Path $Dl $cpuZip
  $cpuDir=Runtime-Destination 'cpu'
  if(-not(Runtime-Ready $cpuDir 'cpu')){
    Download ($Release+$cpuZip) $cpuZipPath 0 1000000 'b2d794fa7587aba29f654d717ff9b73e31caeabf50a7766692903008bbe0855d' 0 5 34
    Publish (Say 'Подготовка на CPU резервен режим' 'Preparing safe CPU fallback') 0 35
    Unpack $cpuZipPath $cpuDir
    Commit-Runtime $cpuDir 'cpu'
  }
  Publish (Say 'CPU резервен режим е готов' 'CPU fallback ready') 0 45

  $backendDir=$cpuDir
  if($script:Backend -ne 'cpu'){
    $pkg=if($script:Backend -eq 'cuda'){'llama-b12651-bin-win-cuda-12.4-x64.zip'}else{'llama-b12651-bin-win-vulkan-x64.zip'}
    $destDir=Runtime-Destination $script:Backend
    $runtimeReady=Runtime-Ready $destDir $script:Backend
    if(-not $runtimeReady){
      $pkgPath=Join-Path $Dl $pkg
      $hash=if($script:Backend -eq 'vulkan'){'e58fa9a137d8046c69334005ad6fb3e904ddc7e56f2a61ad1b844335826ef3f4'}else{'1a6c090f76fab41260b5b7597c6fb1add1fad2efaac692ae2673a22366220a29'}
      Download ($Release+$pkg) $pkgPath 0 1000000 $hash 0 45 83
      Publish (Say 'Разархивиране на GPU двигателя' 'Extracting GPU runtime') 0 84
      Unpack $pkgPath $destDir
    }
    if(-not $runtimeReady -and $script:Backend -eq 'cuda'){
      $dllPkg='cudart-llama-bin-win-cuda-12.4-x64.zip'
      $dllZip=Join-Path $Dl $dllPkg
      if(-not(Test-Path (Join-Path $destDir 'cublas64_12.dll'))){
        Download ($Release+$dllPkg) $dllZip 0 1000000 '8c79a9b226de4b3cacfd1f83d24f962d0773be79f1e7b75c6af4ded7e32ae1d6' 0 84 94
        $dllTmp=Join-Path $Root ('cuda-tmp-'+$RunId)
        Expand-Archive -LiteralPath $dllZip -DestinationPath $dllTmp -Force
        $dlls=Get-ChildItem $dllTmp -Recurse -File | Where-Object {$_.Extension -eq '.dll'}
        if(-not @($dlls).Count){throw 'No CUDA libraries found in official archive.'}
        foreach($d in $dlls){Copy-Item -LiteralPath $d.FullName -Destination (Join-Path $destDir $d.Name) -Force}
        Remove-Item $dllTmp -Recurse -Force
      }
    }
    if(-not $runtimeReady){Commit-Runtime $destDir $script:Backend}
    $backendDir=$destDir
  }
  Publish ((Say 'AI двигател:' 'Runtime:')+' '+$script:Backend) 0 100
  Check-Cancel

  # STAGE 2: Official INSAIT BgGPT Q6_K GGUF (3.18 GB)
  Publish (Say 'Проверка на BgGPT (INSAIT)...' 'Checking INSAIT BgGPT...') 1 0
  if($ForceModel -or -not(Verified $ModelPath 3100000000L $ModelSha)){
    if($ForceModel -and (Test-Path $ModelPath)){
      $fresh=Join-Path $Dl ('fresh-'+$ModelName)
      if(Test-Path $fresh){Remove-Item $fresh -Force}
      Download $ModelUrl $fresh $ModelSize 3100000000L $ModelSha 1 0 100
      Copy-Item -LiteralPath $fresh -Destination $ModelPath -Force
      Remove-Item $fresh -Force
    }else{Download $ModelUrl $ModelPath $ModelSize 3100000000L $ModelSha 1 0 100}
  }else{
    Record 'Reusing verified INSAIT GGUF model'
    Publish (Say 'Проверен BgGPT е наличен' 'Verified BgGPT already installed') 1 100
  }
  if(-not(Verified $ModelPath 3100000000L $ModelSha)){throw 'INSAIT model verification failed'}
  Check-Cancel

  # STAGE 3: AnythingLLM Desktop
  Publish (Say 'Проверка на AnythingLLM' 'Checking AnythingLLM') 2 0
  $script:AnyExe=Find-Anything
  if(-not $script:AnyExe){
    $setup=Join-Path $Dl 'AnythingLLMDesktop.exe'
    Download $AnythingUrl $setup 0 100000000 '' 2 0 90
    Publish (Say 'Инсталиране на AnythingLLM' 'Installing AnythingLLM') 2 95
    $installer=Start-Process -FilePath $setup -ArgumentList '/S' -PassThru
    while(-not $installer.HasExited){Check-Cancel; Start-Sleep -Milliseconds 500; $installer.Refresh()}
    if($installer.ExitCode -ne 0){throw ('AnythingLLM installer exit '+$installer.ExitCode)}
    $script:AnyExe=Find-Anything
    if(-not $script:AnyExe){Record 'AnythingLLM installer finished but executable path not found.'; Publish (Say 'AnythingLLM: инсталирано, но пътят не е открит' 'AnythingLLM: installer finished, executable not located') 2 98}
  }
  Publish (Say 'AnythingLLM обработен' 'AnythingLLM step completed') 2 100
  Check-Cancel

  # STAGE 4: Launcher, shortcuts, fast server start, and quick self-test
  Publish (Say 'Настройка на стартовите файлове...' 'Setting up launcher...') 3 10
  foreach($name in @('START.cmd','CONFIGURE.cmd','Start-BgGPT.ps1','CONFIGURATION-BG-EN.txt','NOTICE.txt','README_BG.md','README_EN.md')){
    Copy-Item -LiteralPath (Join-Path $SourceDir $name) -Destination (Join-Path $Root $name) -Force
  }
  $config=@{
    backend=$script:Backend; legacyAmd=$oldAmd; gpu=$script:Gpu; runtime=$backendDir; cpuRuntime=$cpuDir;
    model=$ModelPath; anything=$script:AnyExe; modelAlias=$ModelName; contextSize=4096; version='v12-final'
  }
  [IO.File]::WriteAllText((Join-Path $Root 'config.json'),($config|ConvertTo-Json -Depth 4),[Text.Encoding]::UTF8)
  Create-Shortcuts

  Stop-OwnServerIfVision $backendDir $cpuDir $ModelPath

  Publish (Say 'Пускане на локалния AI сървър...' 'Starting local AI server...') 3 35
  $run=Start-Process -FilePath (Join-Path $Root 'CONFIGURE.cmd') -WorkingDirectory $Root -PassThru
  $ready=$false
  for($i=0;$i -lt 110;$i++){
    Check-Cancel
    try{
      $r=Invoke-RestMethod -Uri 'http://127.0.0.1:8080/v1/models' -TimeoutSec 2
      if(@($r.data | Where-Object {([string]$_.id).EndsWith($ModelName,[StringComparison]::OrdinalIgnoreCase)}).Count -gt 0){$ready=$true;break}
    }catch{}
    Start-Sleep -Milliseconds 700
  }
  if(-not $ready){throw 'Local AI server did not become ready. See logs\server-error.log'}

  Publish (Say 'Бърз локален тест на чата (127.0.0.1:8080)...' 'Running quick local chat self-test (127.0.0.1:8080)...') 3 70
  Verify-LocalText $ModelName

  $doneMsg=Say 'Готово! Бързият локален BgGPT чат (контекст 4096) е проверен и активен.' 'Ready! Fast local BgGPT chat (4096 context) is verified and active.'

  Publish $doneMsg 3 100 'done'
  Record 'BgGPT v12-final installed and verified.'
}catch{
  $message=$_.Exception.Message
  Record ('ERROR: '+$message)
  Publish $message -1 -1 'error'
  exit 1
} finally {
  if($mutexOwned -and $installMutex){try{$installMutex.ReleaseMutex()}catch{}}
  if($installMutex){$installMutex.Dispose()}
}
