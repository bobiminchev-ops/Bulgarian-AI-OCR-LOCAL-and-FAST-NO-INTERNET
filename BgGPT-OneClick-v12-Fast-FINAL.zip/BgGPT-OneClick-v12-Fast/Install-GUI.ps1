﻿# BgGPT — OneClick Universal v12 Final. WinForms main UI remains responsive; worker handles IO in a separate process.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
Add-Type -WarningAction SilentlyContinue -ReferencedAssemblies 'System.Windows.Forms','System.Drawing' -TypeDefinition @'
using System;
using System.Drawing;
using System.Drawing.Text;
using System.Windows.Forms;

public sealed class MatrixRainPanelV12Fast : Panel
{
    private readonly Timer clock;
    private readonly Random random = new Random();
    private float[] heads = new float[0];
    private float[] speeds = new float[0];
    private int[] tails = new int[0];
    private readonly Font rainFont;
    private const int Gap = 19;
    private const int Line = 20;
    private const string Alphabet = "0123456789ABCDEF+-*/<>:;";

    public MatrixRainPanelV12Fast()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint |
                 ControlStyles.OptimizedDoubleBuffer |
                 ControlStyles.UserPaint |
                 ControlStyles.SupportsTransparentBackColor, true);
        BackColor = Color.FromArgb(22, 34, 49);
        rainFont = new Font("Consolas", 10.2f, FontStyle.Regular, GraphicsUnit.Point);
        clock = new Timer();
        clock.Interval = 95;
        clock.Tick += delegate(object sender, EventArgs e)
        {
            for (int i = 0; i < heads.Length; i++)
            {
                heads[i] += speeds[i];
                if (heads[i] > Height + tails[i] * Line)
                    heads[i] = -random.Next(15, 170);
            }
            Invalidate();
        };
        RebuildColumns();
        clock.Start();
    }

    private void RebuildColumns()
    {
        int count = Math.Max(1, Width / Gap);
        heads = new float[count];
        speeds = new float[count];
        tails = new int[count];
        for (int i = 0; i < count; i++)
        {
            heads[i] = random.Next(-Height, Math.Max(50, Height));
            speeds[i] = 1.8f + (float)random.NextDouble() * 2.6f;
            tails[i] = 9 + random.Next(8);
        }
    }

    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);
        if (random != null) RebuildColumns();
    }

    protected override void OnPaintBackground(PaintEventArgs e)
    {
        e.Graphics.Clear(BackColor);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        e.Graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
        for (int c = 0; c < heads.Length; c++)
        {
            if (c % 7 == 3) continue;
            float x = 7 + c * Gap;
            for (int j = 0; j < tails[c]; j++)
            {
                float y = heads[c] - j * Line;
                if (y < -Line || y > Height) continue;
                int alpha = j == 0 ? 238 : Math.Max(24, 160 - j * 10);
                Color tint = j == 0
                    ? Color.FromArgb(alpha, 232, 255, 238)
                    : Color.FromArgb(alpha, 44, 255, 123);
                char symbol = Alphabet[random.Next(Alphabet.Length)];
                using (Brush b = new SolidBrush(tint))
                    e.Graphics.DrawString(symbol.ToString(), rainFont, b, x, y);
            }
        }
        using (Brush shade = new SolidBrush(Color.FromArgb(85, 12, 24, 35)))
        {
            e.Graphics.FillRectangle(shade, 18, 20, Math.Max(0, Width - 36), 207);
            e.Graphics.FillRectangle(shade, 18, 228, Math.Max(0, Width - 36), 337);
            e.Graphics.FillRectangle(shade, 18, Math.Max(435, Height-190), Math.Max(0, Width - 36), 150);
        }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            clock.Stop();
            clock.Dispose();
            rainFont.Dispose();
        }
        base.Dispose(disposing);
    }
}
'@

$script:Lang = 'bg'
$script:Running = $false
$script:Finished = $false
$script:Worker = $null
$script:Root = Join-Path $env:LOCALAPPDATA 'BgGPT-Local'
$script:RunId = ''
$script:StatusPath = ''
$script:CancelPath = ''
$script:BaseDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:Ui = @{
 bg = @{
  title='BgGPT'; top='ONECLICK UNIVERSAL  /  v12 FINAL'; tag='БЪЛГАРСКИ ИЗКУСТВЕН ИНТЕЛЕКТ';
  hero="Една инсталация.`r`nБългарски изкуствен`r`nинтелект.`r`nСвободен";
  side='Моделът на INSAIT. Бърз локален чат и научна библиотека. Без облачна обработка.';
  label='ПРОЦЕС НА ИНСТАЛАЦИЯТА';
  info='Без Python. Автоматичен AI двигател за NVIDIA / AMD / Intel / CPU, контекст 4096 токена и безопасен CPU резервен режим.';
  stages=@('1   Хардуер и AI двигател','2   BgGPT / INSAIT · 3,18 GB','3   AnythingLLM Desktop','4   Локален чат, тест и икона');
  state='Готов за инсталация'; hint='Изтегля се от официалните източници. Вече наличният проверен BgGPT се използва повторно.';
  confirm='Потвърди с YES'; install='ИНСТАЛИРАЙ'; cancel='ОТКАЖИ'; chat='CHAT';
  redownload='Изтегли отново BgGPT от INSAIT (3,18 GB)';
  total='ОБЩ НАПРЕДЪК'; log='СЪСТОЯНИЕ';
  complete='Готово! Бързият локален AI чат е проверен и достъпен.';
  failed='Инсталацията е прекъсната или е възникнала грешка. Виж logs\install.log.';
  needConfirm='За начало въведи YES точно до бутона «Инсталирай».';
  source='Официални източници: INSAIT · llama.cpp · AnythingLLM'
 };
 en = @{
  title='BgGPT'; top='ONECLICK UNIVERSAL  /  v12 FINAL'; tag='BULGARIAN ARTIFICIAL INTELLIGENCE';
  hero="One installation.`r`nBulgarian artificial`r`nintelligence.`r`nFree";
  side='INSAIT model. Fast local chat and document library. Zero cloud processing.';
  label='INSTALLATION PROGRESS';
  info='Zero Python. Automatic runtime for NVIDIA / AMD / Intel / CPU, 4096-token context window, and safe CPU fallback.';
  stages=@('1   Hardware and AI runtime','2   BgGPT / INSAIT · 3.18 GB','3   AnythingLLM Desktop','4   Local chat, self-test and shortcut');
  state='Ready to install'; hint='Downloads are from official sources. Existing verified BgGPT model is reused.';
  confirm='Confirm with YES'; install='INSTALL'; cancel='CANCEL'; chat='CHAT';
  redownload='Download BgGPT again from INSAIT (3.18 GB)';
  total='TOTAL PROGRESS'; log='STATUS';
  complete='Complete! Fast local AI chat is verified and ready.';
  failed='Installation stopped or failed. Please review logs\install.log.';
  needConfirm='Enter YES beside Install to start.';
  source='Official sources: INSAIT · llama.cpp · AnythingLLM'
 }
}
function U([string]$k){return [string]$script:Ui[$script:Lang][$k]}
$C=@{bg=[Drawing.Color]::FromArgb(11,18,29); mid=[Drawing.Color]::FromArgb(22,32,47); stroke=[Drawing.Color]::FromArgb(56,76,88); main=[Drawing.Color]::FromArgb(244,249,250); dim=[Drawing.Color]::FromArgb(157,177,193); green=[Drawing.Color]::FromArgb(66,221,148); aqua=[Drawing.Color]::FromArgb(43,194,183)}
function Font([float]$sz,[bool]$bold=$false){$style=if($bold){[Drawing.FontStyle]::Bold}else{[Drawing.FontStyle]::Regular};return [Drawing.Font]::new('Segoe UI',$sz,$style)}
function Label($parent,[int]$x,[int]$y,[int]$w,[int]$h,[string]$txt,[int]$fs=11,[bool]$bold=$false,$fg=$C.main){
 $l=New-Object Windows.Forms.Label
 $l.SetBounds($x,$y,$w,$h)
 $l.Text=$txt;$l.ForeColor=$fg;$l.Font=Font $fs $bold
 $l.BackColor=[Drawing.Color]::Transparent
 $l.AutoSize=$false
 $parent.Controls.Add($l)
 return $l
}
function Button($parent,[int]$x,[int]$y,[int]$w,[int]$h,[string]$txt,$bgc=$C.mid){
 $b=New-Object Windows.Forms.Button
 $b.SetBounds($x,$y,$w,$h)
 $b.Text=$txt;$b.BackColor=$bgc;$b.ForeColor=$C.main;$b.FlatStyle='Flat'
 $b.FlatAppearance.BorderSize=0
 $b.Font=Font 10 $true
 $b.Cursor=[Windows.Forms.Cursors]::Hand
 $parent.Controls.Add($b)
 return $b
}
function Bar($parent,[int]$x,[int]$y,[int]$w,[int]$h){
 $b=New-Object Windows.Forms.ProgressBar
 $b.SetBounds($x,$y,$w,$h)
 $b.Style='Continuous';$b.Maximum=100;$b.Minimum=0;$b.Value=0
 $parent.Controls.Add($b);return $b
}
$form=New-Object Windows.Forms.Form
$form.Text='BgGPT — OneClick Universal v12 Final'
$form.StartPosition='CenterScreen'
$form.Size=[Drawing.Size]::new(1050,724)
$form.MinimumSize=[Drawing.Size]::new(1050,724)
$form.MaximumSize=[Drawing.Size]::new(1050,724)
$form.BackColor=$C.bg
$form.Font=Font 10
$form.FormBorderStyle='FixedSingle'
$form.MaximizeBox=$false
$form.ShowIcon=$false
$form.AutoScaleMode='Font'
$matrix=New-Object MatrixRainPanelV12Fast
$matrix.SetBounds(0,0,373,685)
$matrix.Anchor='Top,Bottom,Left'
$form.Controls.Add($matrix)
$brand=Label $matrix 23 30 325 74 (U 'title') 29 $true $C.main
$tag=Label $matrix 25 111 333 55 (U 'tag') 10 $true $C.green
$hero=Label $matrix 25 205 336 175 (U 'hero') 19 $true $C.main
$side=Label $matrix 25 393 326 96 (U 'side') 10 $false $C.main
$source=Label $matrix 23 593 326 50 (U 'source') 9 $false $C.green

$panel=New-Object Windows.Forms.Panel
$panel.SetBounds(373,0,660,685)
$panel.BackColor=$C.bg
$form.Controls.Add($panel)
$eng=Button $panel 482 18 75 32 'EN' $C.mid
$bul=Button $panel 568 18 75 32 'BG' $C.mid
$top=Label $panel 23 20 448 32 (U 'top') 13 $true $C.green
$title=Label $panel 25 68 600 37 (U 'label') 20 $true $C.main
$info=Label $panel 25 110 608 66 (U 'info') 10 $false $C.dim
$script:Bars=@();$script:Vals=@();$script:Names=@();$script:Notes=@()
for($i=0;$i -lt 4;$i++){
  $y=186+$i*69
  $script:Names+=,(Label $panel 27 $y 480 27 ([string]$script:Ui[$script:Lang]['stages'][$i]) 11 $true $C.main)
  $script:Vals+=,(Label $panel 540 $y 87 25 '0,00%' 10 $true $C.green)
  $script:Bars+=,(Bar $panel 27 ($y+28) 592 12)
  $script:Notes+=,(Label $panel 27 ($y+43) 592 20 '' 9 $false $C.dim)
}
$overallName=Label $panel 26 468 400 23 (U 'total') 10 $true $C.dim
$overallVal=Label $panel 536 468 83 23 '0,00%' 10 $true $C.green
$overall=Bar $panel 27 494 592 15
$statusName=Label $panel 25 526 160 22 (U 'log') 10 $true $C.dim
$status=Label $panel 26 551 596 49 (U 'state') 10 $false $C.main
$force=New-Object Windows.Forms.CheckBox
$force.SetBounds(29,611,591,22)
$force.Text=U 'redownload';$force.ForeColor=$C.dim;$force.Font=Font 9
$panel.Controls.Add($force)
$confirmName=Label $panel 26 637 137 29 (U 'confirm') 10 $true $C.main
$yes=New-Object Windows.Forms.TextBox
$yes.SetBounds(165,637,77,27)
$yes.BackColor=$C.mid;$yes.ForeColor=$C.main;$yes.BorderStyle='FixedSingle'
$yes.TextAlign='Center';$yes.CharacterCasing='Upper';$yes.MaxLength=3;$yes.Font=Font 12 $true
$panel.Controls.Add($yes)
$install=Button $panel 256 634 185 34 (U 'install') $C.aqua
$cancel=Button $panel 452 634 107 34 (U 'cancel') $C.mid
$chat=Button $panel 567 634 80 34 'CHAT' $C.mid
$chat.Enabled=$false

function Format-Percent([double]$value){
 $culture=if($script:Lang -eq 'bg'){[Globalization.CultureInfo]::GetCultureInfo('bg-BG')}else{[Globalization.CultureInfo]::GetCultureInfo('en-US')}
 return $value.ToString('N2',$culture)+'%'
}
function Render-Language {
 $tag.Text=U 'tag';$hero.Text=U 'hero';$side.Text=U 'side';$source.Text=U 'source'
 $top.Text=U 'top';$title.Text=U 'label';$info.Text=U 'info'
 for($i=0;$i -lt 4;$i++){$script:Names[$i].Text=$script:Ui[$script:Lang]['stages'][$i]}
 $overallName.Text=U 'total';$statusName.Text=U 'log';$force.Text=U 'redownload';$confirmName.Text=U 'confirm'
 $install.Text=U 'install';$cancel.Text=U 'cancel'
 for($i=0;$i -lt 4;$i++){ $script:Vals[$i].Text=Format-Percent ([double]$script:Bars[$i].Value) }
 $overallVal.Text=Format-Percent ([double]$overall.Value)
 if(-not $script:Running -and -not $script:Finished){$status.Text=U 'state'}
}
$bul.Add_Click({$script:Lang='bg';Render-Language})
$eng.Add_Click({$script:Lang='en';Render-Language})
$chat.Add_Click({Start-Process 'http://127.0.0.1:8080'})
$install.Add_Click({
 if($script:Running){return}
 if($yes.Text -cne 'YES'){$status.Text=U 'needConfirm';return}
 try{
  New-Item -Path $script:Root -ItemType Directory -Force | Out-Null
  $script:RunId=[guid]::NewGuid().ToString('N')
  $script:StatusPath=Join-Path $script:Root ('install-status-'+$script:RunId+'.json')
  $script:CancelPath=Join-Path $script:Root ('install-cancel-'+$script:RunId+'.flag')
  $args='-NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $script:BaseDir 'Install-Worker.ps1')+'" -Language '+$script:Lang+' -RunId '+$script:RunId
  if($force.Checked){$args+=' -ForceModel'}
  $script:Worker=Start-Process -FilePath 'powershell.exe' -ArgumentList $args -WorkingDirectory $script:BaseDir -PassThru -WindowStyle Hidden
  $script:Running=$true;$script:Finished=$false
  $yes.Enabled=$false;$install.Enabled=$false;$force.Enabled=$false;$chat.Enabled=$false
  $status.Text=U 'hint'
  for($i=0;$i -lt 4;$i++){$script:Bars[$i].Value=0;$script:Vals[$i].Text=Format-Percent 0.0;$script:Notes[$i].Text=''}
  $overall.Value=0;$overallVal.Text=Format-Percent 0.0
 }catch{$status.Text='ERROR: '+$_.Exception.Message}
})
$cancel.Add_Click({
 if($script:Running){New-Item -Path $script:CancelPath -ItemType File -Force | Out-Null;$status.Text=if($script:Lang -eq 'bg'){'Отказване на инсталацията...'}else{'Cancelling installation...'}}
 else{$form.Close()}
})
$timer=New-Object Windows.Forms.Timer
$timer.Interval=450
$timer.Add_Tick({
 if(-not $script:Running){return}
 try{
  if(Test-Path $script:StatusPath){
   $json=Get-Content -LiteralPath $script:StatusPath -Raw -Encoding UTF8 | ConvertFrom-Json
   for($i=0;$i -lt 4;$i++){
    $p=[double]$json.progress[$i]
    $p=[Math]::Max(0.0,[Math]::Min(100.0,$p))
    $script:Bars[$i].Value=[int][Math]::Round($p)
    $script:Vals[$i].Text=Format-Percent $p
    if($json.labels[$i]){$script:Notes[$i].Text=[string]$json.labels[$i]}
   }
   $total=[Math]::Max(0.0,[Math]::Min(100.0,[double]$json.total))
   $overall.Value=[int][Math]::Round($total);$overallVal.Text=Format-Percent $total
   $status.Text=[string]$json.note
   if($json.kind -eq 'done'){
    $script:Running=$false;$script:Finished=$true
    $chat.Enabled=$true
    $install.Enabled=$true;$yes.Enabled=$true;$force.Enabled=$true
    if([string]$json.note){$status.Text=[string]$json.note}else{$status.Text=U 'complete'}
   }elseif($json.kind -eq 'error'){
    $script:Running=$false;$install.Enabled=$true;$yes.Enabled=$true;$force.Enabled=$true
    $status.Text='ERROR: '+[string]$json.note
   }
  }
  if($script:Worker -and $script:Running){
   $script:Worker.Refresh()
   if($script:Worker.HasExited -and $script:Running){
    $script:Running=$false;$install.Enabled=$true;$yes.Enabled=$true;$force.Enabled=$true
    $status.Text=U 'failed'
    if($script:Worker.ExitCode -ne 0){$status.Text+='  logs\install.log'}
   }
  }
 }catch{}
})
$timer.Start()
$form.Add_FormClosing({
 if($script:Running){
   try{New-Item -Path $script:CancelPath -ItemType File -Force | Out-Null}catch{}
 }
})
[void]$form.ShowDialog()
$timer.Stop();$timer.Dispose()
