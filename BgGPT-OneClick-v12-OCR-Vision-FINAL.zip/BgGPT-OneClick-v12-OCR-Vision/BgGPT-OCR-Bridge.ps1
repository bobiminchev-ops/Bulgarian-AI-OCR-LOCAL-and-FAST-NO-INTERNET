﻿# BgGPT Local Hybrid Offline OCR + SmolVLM2-2.2B Vision Bridge (Port 8080 -> llama-server on Port 8081)
# 100% local, zero Python, zero Admin privileges required (uses TcpListener on 127.0.0.1).
# - Pure text chats: zero-delay SSE streaming directly to fast BgGPT (port 8081).
# - Text-heavy images (documents/tables/screenshots): 1-2s offline Windows.Media.Ocr.
# - Photos/objects/charts/diagrams: automatic on-demand SmolVLM2-2.2B via llama-mtmd-cli.exe (CPU, frees RAM immediately).
param(
  [int]$ListenPort = 8080,
  [int]$UpstreamPort = 8081
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Web.Extensions
Add-Type -AssemblyName System.Runtime.WindowsRuntime

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Logs = Join-Path $Root 'logs'
New-Item -ItemType Directory -Path $Logs -Force | Out-Null
$LogPath = Join-Path $Logs 'ocr-bridge.log'

function Write-BridgeLog([string]$msg) {
  $line = '[' + [DateTime]::Now.ToString('HH:mm:ss') + '] ' + $msg
  try { Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8 } catch {}
  Write-Host $line
}

# ============================================================================
# Read SmolVLM2-2.2B Vision Helper Config from config.json
# ============================================================================
$script:VisionReady = $false
$script:MtmdCliPath = ''
$script:VisionModelPath = ''
$script:VisionMmprojPath = ''
$script:VisionModelName = ''

$confPath = Join-Path $Root 'config.json'
if (Test-Path -LiteralPath $confPath) {
  try {
    $cfg = Get-Content -LiteralPath $confPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $candCli = @()
    if ($cfg.PSObject.Properties.Name -contains 'cpuRuntime' -and $cfg.cpuRuntime) {
      $candCli += (Join-Path ([string]$cfg.cpuRuntime) 'llama-mtmd-cli.exe')
    }
    if ($cfg.PSObject.Properties.Name -contains 'runtime' -and $cfg.runtime) {
      $candCli += (Join-Path ([string]$cfg.runtime) 'llama-mtmd-cli.exe')
    }
    foreach ($cli in $candCli) {
      if (Test-Path -LiteralPath $cli -PathType Leaf) {
        $script:MtmdCliPath = $cli
        break
      }
    }
    if ($cfg.PSObject.Properties.Name -contains 'visionModel' -and $cfg.visionModel) {
      $script:VisionModelPath = [string]$cfg.visionModel
    }
    if ($cfg.PSObject.Properties.Name -contains 'visionMmproj' -and $cfg.visionMmproj) {
      $script:VisionMmprojPath = [string]$cfg.visionMmproj
    }
    if ($script:MtmdCliPath -and $script:VisionModelPath -and $script:VisionMmprojPath -and
        (Test-Path -LiteralPath $script:VisionModelPath -PathType Leaf) -and
        (Test-Path -LiteralPath $script:VisionMmprojPath -PathType Leaf)) {
      $script:VisionReady = $true
      $script:VisionModelName = [IO.Path]::GetFileName($script:VisionModelPath)
      Write-BridgeLog ('SmolVLM2 Vision Helper active: ' + $script:VisionModelName + ' via ' + $script:MtmdCliPath)
    } else {
      Write-BridgeLog 'SmolVLM2 Vision Helper not configured or files missing (running in Windows OCR-only mode).'
    }
  } catch {
    Write-BridgeLog ('Config read warning: ' + $_.Exception.Message)
  }
}

# ============================================================================
# Initialize Windows 10/11 Native Offline OCR (WinRT) on Main PowerShell Thread
# ============================================================================
$script:OcrReady = $false
$script:PrimaryEngine = $null
$script:FallbackEngine = $null
$script:PrimaryLangTag = ''
$script:FallbackLangTag = ''

try {
  $null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
  $null = [Windows.Storage.FileAccessMode, Windows.Storage, ContentType = WindowsRuntime]
  $null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime]
  $null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
  $null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
  $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
  $null = [Windows.Media.Ocr.OcrResult, Windows.Foundation, ContentType = WindowsRuntime]
  $null = [Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime]

  $script:AsTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
  })[0]

  $avail = @([Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages)
  $tags = @($avail | ForEach-Object { [string]$_.LanguageTag })
  Write-BridgeLog ('Available Windows OCR languages: ' + ($tags -join ', '))

  $bgLang = $avail | Where-Object { $_.LanguageTag -like 'bg*' } | Select-Object -First 1
  $enLang = $avail | Where-Object { $_.LanguageTag -like 'en*' } | Select-Object -First 1

  if ($null -ne $bgLang) {
    $script:PrimaryEngine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($bgLang)
    $script:PrimaryLangTag = [string]$bgLang.LanguageTag
    if ($null -ne $enLang) {
      $script:FallbackEngine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($enLang)
      $script:FallbackLangTag = [string]$enLang.LanguageTag
    }
  } elseif ($null -ne $enLang) {
    $script:PrimaryEngine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($enLang)
    $script:PrimaryLangTag = [string]$enLang.LanguageTag
  } else {
    $script:PrimaryEngine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
    if ($null -ne $script:PrimaryEngine) {
      $script:PrimaryLangTag = [string]$script:PrimaryEngine.RecognizerLanguage.LanguageTag
    }
  }

  if ($null -ne $script:PrimaryEngine) {
    $script:OcrReady = $true
    Write-BridgeLog ('OCR Engine active. Primary: ' + $script:PrimaryLangTag + ' | Fallback: ' + $script:FallbackLangTag)
  } else {
    Write-BridgeLog 'WARNING: No Windows OCR language pack found. Install bg-BG or en-US OCR capability.'
  }
} catch {
  Write-BridgeLog ('WARNING: WinRT OCR init failed: ' + $_.Exception.Message)
}

function Await-WinRT($WinRtTask, [Type]$ResultType) {
  $asTask = $script:AsTaskGeneric.MakeGenericMethod($ResultType)
  $netTask = $asTask.Invoke($null, @($WinRtTask))
  return $netTask.GetAwaiter().GetResult()
}

function Invoke-WinRtOcrFile([string]$pngPath) {
  if (-not $script:OcrReady -or $null -eq $script:PrimaryEngine) {
    return ''
  }
  $stream = $null
  $softBmp = $null
  try {
    $storageFile = Await-WinRT ([Windows.Storage.StorageFile]::GetFileFromPathAsync($pngPath)) ([Windows.Storage.StorageFile])
    $stream = Await-WinRT ($storageFile.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
    $decoder = Await-WinRT ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $softBmp = Await-WinRT ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])

    $res = Await-WinRT ($script:PrimaryEngine.RecognizeAsync($softBmp)) ([Windows.Media.Ocr.OcrResult])
    $lines = @($res.Lines | ForEach-Object { [string]$_.Text })
    $text = ($lines -join "`n").Trim()

    if ([string]::IsNullOrWhiteSpace($text) -and $null -ne $script:FallbackEngine) {
      $res2 = Await-WinRT ($script:FallbackEngine.RecognizeAsync($softBmp)) ([Windows.Media.Ocr.OcrResult])
      $lines2 = @($res2.Lines | ForEach-Object { [string]$_.Text })
      $text = ($lines2 -join "`n").Trim()
    }
    return $text
  } finally {
    if ($softBmp) { try { $softBmp.Dispose() } catch {} }
    if ($stream) { try { $stream.Dispose() } catch {} }
  }
}

# ============================================================================
# Compiled C# 5.0 Multi-threaded Hybrid OCR + SmolVLM2 Streaming Proxy
# ============================================================================
Add-Type -WarningAction SilentlyContinue -ReferencedAssemblies 'System.Web.Extensions','System.Drawing' -TypeDefinition @'
using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;

public sealed class BgGptOcrJob
{
    public string TempPngPath;
    public string ResultText;
    public string ErrorMessage;
    public ManualResetEventSlim Done = new ManualResetEventSlim(false);
}

public sealed class BgGptHybridProxy : IDisposable
{
    private readonly int listenPort;
    private readonly int upstreamPort;
    private readonly string primaryLang;
    private readonly bool ocrReady;
    private readonly bool visionReady;
    private readonly string mtmdCliPath;
    private readonly string visionModelPath;
    private readonly string visionMmprojPath;
    private readonly string visionModelName;

    private TcpListener listener;
    private volatile bool running;
    private Thread acceptThread;
    private readonly ConcurrentQueue<BgGptOcrJob> ocrQueue = new ConcurrentQueue<BgGptOcrJob>();
    private readonly AutoResetEvent jobSignal = new AutoResetEvent(false);
    private readonly ConcurrentDictionary<string, string> imageCache = new ConcurrentDictionary<string, string>();
    private readonly ConcurrentQueue<string> logQueue = new ConcurrentQueue<string>();
    private readonly SemaphoreSlim visionLock = new SemaphoreSlim(1, 1);

    private static readonly Regex VisualIntentRegex = new Regex(
        "снимк|картин|изображ|графика|диаграм|карта|цвят|цвет|виждаш|какво е това|какво има|опиши|обект|животн|котка|куче|сграда|хотел|chart|graph|map|photo|image|picture|color|colour|describe|what is this|what do you see",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    public BgGptHybridProxy(
        int listenPort,
        int upstreamPort,
        bool ocrReady,
        string primaryLang,
        bool visionReady,
        string mtmdCliPath,
        string visionModelPath,
        string visionMmprojPath,
        string visionModelName)
    {
        this.listenPort = listenPort;
        this.upstreamPort = upstreamPort;
        this.ocrReady = ocrReady;
        this.primaryLang = primaryLang ?? "";
        this.visionReady = visionReady;
        this.mtmdCliPath = mtmdCliPath ?? "";
        this.visionModelPath = visionModelPath ?? "";
        this.visionMmprojPath = visionMmprojPath ?? "";
        this.visionModelName = visionModelName ?? "";
    }

    public void Start()
    {
        listener = new TcpListener(IPAddress.Loopback, listenPort);
        listener.Start(64);
        running = true;
        acceptThread = new Thread(AcceptLoop);
        acceptThread.IsBackground = true;
        acceptThread.Start();
    }

    public bool TryDequeueLog(out string msg)
    {
        return logQueue.TryDequeue(out msg);
    }

    public BgGptOcrJob WaitForOcrJob(int timeoutMs)
    {
        BgGptOcrJob job;
        if (ocrQueue.TryDequeue(out job)) return job;
        jobSignal.WaitOne(timeoutMs);
        if (ocrQueue.TryDequeue(out job)) return job;
        return null;
    }

    private void Log(string msg)
    {
        logQueue.Enqueue(msg);
    }

    private void AcceptLoop()
    {
        while (running)
        {
            try
            {
                TcpClient client = listener.AcceptTcpClient();
                ThreadPool.QueueUserWorkItem(HandleClient, client);
            }
            catch
            {
                if (!running) break;
                Thread.Sleep(50);
            }
        }
    }

    private static byte[] ReadHeaderBytes(NetworkStream ns)
    {
        MemoryStream ms = new MemoryStream();
        int matched = 0;
        while (ms.Length < 65536)
        {
            int b = ns.ReadByte();
            if (b == -1) break;
            ms.WriteByte((byte)b);
            if ((matched == 0 && b == 13) || (matched == 1 && b == 10) ||
                (matched == 2 && b == 13) || (matched == 3 && b == 10))
            {
                matched++;
                if (matched == 4) break;
            }
            else
            {
                matched = (b == 13) ? 1 : 0;
            }
        }
        return ms.ToArray();
    }

    private static string ReadAsciiLine(Stream s)
    {
        MemoryStream ms = new MemoryStream();
        bool gotAny = false;
        while (ms.Length < 4096)
        {
            int b = s.ReadByte();
            if (b == -1) break;
            gotAny = true;
            if (b == 10) break;
            if (b != 13) ms.WriteByte((byte)b);
        }
        if (!gotAny) return null;
        return Encoding.ASCII.GetString(ms.ToArray());
    }

    private static byte[] ReadExact(Stream s, int count)
    {
        byte[] buf = new byte[count];
        int offset = 0;
        while (offset < count)
        {
            int n = s.Read(buf, offset, count - offset);
            if (n <= 0) break;
            offset += n;
        }
        if (offset == count) return buf;
        byte[] trimmed = new byte[offset];
        Buffer.BlockCopy(buf, 0, trimmed, 0, offset);
        return trimmed;
    }

    private static byte[] ReadChunkedBody(Stream s)
    {
        MemoryStream ms = new MemoryStream();
        while (true)
        {
            string line = ReadAsciiLine(s);
            if (line == null) break;
            int semi = line.IndexOf(';');
            if (semi >= 0) line = line.Substring(0, semi);
            line = line.Trim();
            if (line.Length == 0) continue;
            int size;
            if (!int.TryParse(line, System.Globalization.NumberStyles.HexNumber, null, out size)) break;
            if (size <= 0)
            {
                while (true)
                {
                    string tr = ReadAsciiLine(s);
                    if (string.IsNullOrEmpty(tr)) break;
                }
                break;
            }
            byte[] chunk = ReadExact(s, size);
            ms.Write(chunk, 0, chunk.Length);
            ReadAsciiLine(s);
            if (ms.Length > 64 * 1024 * 1024) break;
        }
        return ms.ToArray();
    }

    private static void WriteSimpleJson(NetworkStream ns, int statusCode, string reason, string json)
    {
        byte[] body = Encoding.UTF8.GetBytes(json);
        string hdr = "HTTP/1.1 " + statusCode + " " + reason + "\r\n" +
                     "Content-Type: application/json; charset=utf-8\r\n" +
                     "Access-Control-Allow-Origin: *\r\n" +
                     "Content-Length: " + body.Length + "\r\n" +
                     "Connection: close\r\n\r\n";
        byte[] hb = Encoding.ASCII.GetBytes(hdr);
        ns.Write(hb, 0, hb.Length);
        ns.Write(body, 0, body.Length);
        ns.Flush();
    }

    private static void SaveResizedPng(Bitmap src, string outPath, int maxDim)
    {
        int w = src.Width;
        int h = src.Height;
        if (w > maxDim || h > maxDim)
        {
            double scale = Math.Min((double)maxDim / w, (double)maxDim / h);
            int nw = Math.Max(1, (int)Math.Floor(w * scale));
            int nh = Math.Max(1, (int)Math.Floor(h * scale));
            using (Bitmap resized = new Bitmap(nw, nh))
            {
                using (Graphics g = Graphics.FromImage(resized))
                {
                    g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    g.DrawImage(src, 0, 0, nw, nh);
                }
                resized.Save(outPath, ImageFormat.Png);
            }
        }
        else
        {
            using (Bitmap copy = new Bitmap(w, h, PixelFormat.Format32bppArgb))
            {
                using (Graphics g = Graphics.FromImage(copy))
                {
                    g.DrawImage(src, 0, 0, w, h);
                }
                copy.Save(outPath, ImageFormat.Png);
            }
        }
    }

    private string RunSmolVlmVision(string imagePngPath)
    {
        if (!visionReady || string.IsNullOrEmpty(mtmdCliPath)) return "";

        visionLock.Wait();
        Stopwatch sw = Stopwatch.StartNew();
        try
        {
            int threads = Math.Max(2, Math.Min(8, Environment.ProcessorCount));
            string prompt = "Describe this image clearly and concisely in English. State the main subject (animal, object, person, chart, map, or scene), colors, shapes, and key visual details.";
            string args = "-m \"" + visionModelPath + "\" " +
                          "--mmproj \"" + visionMmprojPath + "\" " +
                          "--image \"" + imagePngPath + "\" " +
                          "-p \"" + prompt + "\" " +
                          "-n 140 -c 2048 --temp 0.1 --no-warmup -ngl 0 -t " + threads;

            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = mtmdCliPath;
            psi.Arguments = args;
            psi.WorkingDirectory = Path.GetDirectoryName(mtmdCliPath);
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardInput = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.StandardOutputEncoding = Encoding.UTF8;
            psi.StandardErrorEncoding = Encoding.UTF8;

            StringBuilder stdoutSb = new StringBuilder();
            StringBuilder stderrSb = new StringBuilder();

            using (Process proc = new Process())
            {
                proc.StartInfo = psi;
                proc.OutputDataReceived += delegate(object s, DataReceivedEventArgs e)
                {
                    if (e.Data != null) stdoutSb.AppendLine(e.Data);
                };
                proc.ErrorDataReceived += delegate(object s, DataReceivedEventArgs e)
                {
                    if (e.Data != null && stderrSb.Length < 4000) stderrSb.AppendLine(e.Data);
                };

                proc.Start();
                try { proc.StandardInput.Close(); } catch {}
                proc.BeginOutputReadLine();
                proc.BeginErrorReadLine();

                if (!proc.WaitForExit(150000))
                {
                    try { proc.Kill(); } catch {}
                    Log("SmolVLM2 Vision timed out after 150s.");
                    return "";
                }
                // Wait briefly for async output buffers to flush
                proc.WaitForExit();
                sw.Stop();

                if (proc.ExitCode != 0)
                {
                    string errTail = stderrSb.ToString();
                    if (errTail.Length > 500) errTail = errTail.Substring(errTail.Length - 500);
                    Log("SmolVLM2 exit " + proc.ExitCode + ": " + errTail.Replace("\r", " ").Replace("\n", " | "));
                    return "";
                }

                string raw = stdoutSb.ToString();
                raw = raw.Replace("<end_of_utterance>", "").Replace("<|im_end|>", "").Replace("</s>", "");
                // Remove any stray diagnostic lines if emitted to stdout
                string[] lines = raw.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                StringBuilder clean = new StringBuilder();
                for (int i = 0; i < lines.Length; i++)
                {
                    string ln = lines[i].Trim();
                    if (ln.Length == 0) continue;
                    if (ln.StartsWith("llama_perf_", StringComparison.OrdinalIgnoreCase) ||
                        ln.StartsWith("ggml_", StringComparison.OrdinalIgnoreCase) ||
                        ln.StartsWith("encoding image", StringComparison.OrdinalIgnoreCase) ||
                        ln.StartsWith("image decoded", StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }
                    if (clean.Length > 0) clean.Append(" ");
                    clean.Append(ln);
                }

                string desc = clean.ToString().Trim();
                Log("SmolVLM2 described image in " + Math.Round(sw.Elapsed.TotalSeconds, 1) + "s (" + desc.Length + " chars)");
                return desc;
            }
        }
        catch (Exception ex)
        {
            Log("SmolVLM2 error: " + ex.Message);
            return "";
        }
        finally
        {
            visionLock.Release();
        }
    }

    private string AnalyzeImageDataUrl(string dataUrl, string userQuestion)
    {
        int b64Idx = dataUrl.IndexOf("base64,", StringComparison.OrdinalIgnoreCase);
        if (b64Idx < 0)
        {
            return "[Прикачено изображение: неподдържан URL формат.]";
        }
        string b64 = dataUrl.Substring(b64Idx + 7).Trim();
        byte[] rawBytes = Convert.FromBase64String(b64);

        bool wantsVisual = string.IsNullOrEmpty(userQuestion) || VisualIntentRegex.IsMatch(userQuestion);

        string hashKey;
        using (SHA256 sha = SHA256.Create())
        {
            byte[] h = sha.ComputeHash(rawBytes);
            hashKey = BitConverter.ToString(h).Replace("-", "");
        }
        string cacheKey = hashKey + (wantsVisual ? "_V" : "_T");
        string cached;
        if (imageCache.TryGetValue(cacheKey, out cached))
        {
            Log("Image cache hit (" + hashKey.Substring(0, 8) + ")");
            return cached;
        }
        // Also reuse a Vision-enriched cache entry even for text-only follow-ups
        if (!wantsVisual && imageCache.TryGetValue(hashKey + "_V", out cached))
        {
            Log("Image cache hit via V (" + hashKey.Substring(0, 8) + ")");
            return cached;
        }

        string tempOcrPng = Path.Combine(Path.GetTempPath(), "bggpt-ocr-" + Guid.NewGuid().ToString("N") + ".png");
        string tempVisPng = Path.Combine(Path.GetTempPath(), "bggpt-vis-" + Guid.NewGuid().ToString("N") + ".png");
        try
        {
            using (MemoryStream ms = new MemoryStream(rawBytes))
            using (Bitmap src = new Bitmap(ms))
            {
                SaveResizedPng(src, tempOcrPng, 2400);
                if (visionReady)
                {
                    // 640px max dimension keeps SmolVLM2 tiling minimal (~5-18s on CPU) while preserving object/chart detail
                    SaveResizedPng(src, tempVisPng, 512);
                }
            }

            // Step 1: Fast Offline Windows OCR (~1s)
            string extracted = "";
            if (ocrReady)
            {
                BgGptOcrJob job = new BgGptOcrJob();
                job.TempPngPath = tempOcrPng;
                ocrQueue.Enqueue(job);
                jobSignal.Set();

                if (job.Done.Wait(30000) && string.IsNullOrEmpty(job.ErrorMessage))
                {
                    extracted = (job.ResultText ?? "").Trim();
                }
            }
            if (extracted.Length > 8500)
            {
                extracted = extracted.Substring(0, 8500) + "\n...[OCR текстът е съкратен]";
            }

            // Step 2: Decide whether to invoke SmolVLM2-2.2B Vision helper
            // - Always invoke if OCR found little/no text (< 40 chars): photos, animals, objects, scenes!
            // - Also invoke if OCR found moderate text (< 350 chars) AND the user asks about visual elements (charts, maps, colors, "какво е това")!
            // - Skip if dense text document (>= 350 chars) so document OCR stays instant!
            bool runVision = visionReady && ((extracted.Length < 40) || (extracted.Length < 350 && wantsVisual));
            string visionDesc = "";
            if (runVision && File.Exists(tempVisPng))
            {
                visionDesc = RunSmolVlmVision(tempVisPng);
            }

            StringBuilder sb = new StringBuilder();
            if (visionDesc.Length > 0 && extracted.Length > 0)
            {
                sb.Append("[Автоматично визуално описание на прикачената снимка (локален SmolVLM2)]:\n");
                sb.Append(visionDesc);
                sb.Append("\n\n[Автоматично извлечен текст от снимката (локален Windows OCR)]:\n");
                sb.Append(extracted);
                sb.Append("\n[Край на данните от изображението. Отговори ясно и естествено на въпроса на потребителя на неговия език.]");
            }
            else if (visionDesc.Length > 0)
            {
                sb.Append("[Автоматично визуално описание на прикачената снимка (локален SmolVLM2)]:\n");
                sb.Append(visionDesc);
                sb.Append("\n[Край на описанието. Отговори ясно и директно на въпроса на потребителя на български език въз основа на това описание, без да казваш че не виждаш снимката.]");
            }
            else if (extracted.Length > 0)
            {
                sb.Append("[Автоматично извлечен текст от прикачената снимка (локален Windows OCR)]:\n");
                sb.Append(extracted);
                sb.Append("\n[Край на OCR текста]");
            }
            else
            {
                sb.Append("[Прикачено изображение: локалният модул не успя да извлече текст или визуално описание от тази снимка.]");
            }

            string formatted = sb.ToString();
            if (imageCache.Count > 64) imageCache.Clear();
            imageCache[cacheKey] = formatted;
            Log("Analyzed image (" + hashKey.Substring(0, 8) + "): OCR=" + extracted.Length + " chars, Vision=" + visionDesc.Length + " chars");
            return formatted;
        }
        finally
        {
            try { if (File.Exists(tempOcrPng)) File.Delete(tempOcrPng); } catch {}
            try { if (File.Exists(tempVisPng)) File.Delete(tempVisPng); } catch {}
        }
    }

    private void HandleClient(object state)
    {
        TcpClient client = (TcpClient)state;
        try
        {
            client.NoDelay = true;
            client.ReceiveTimeout = 60000;
            client.SendTimeout = 300000;
            using (NetworkStream cStream = client.GetStream())
            {
                byte[] rawHdr = ReadHeaderBytes(cStream);
                if (rawHdr.Length < 10) return;
                string hdrText = Encoding.ASCII.GetString(rawHdr);
                string[] lines = hdrText.Split(new string[] { "\r\n" }, StringSplitOptions.None);
                if (lines.Length == 0) return;

                string[] reqParts = lines[0].Split(' ');
                if (reqParts.Length < 2) return;
                string method = reqParts[0].ToUpperInvariant();
                string target = reqParts[1];

                var headers = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                for (int i = 1; i < lines.Length; i++)
                {
                    if (string.IsNullOrEmpty(lines[i])) break;
                    int colon = lines[i].IndexOf(':');
                    if (colon > 0)
                    {
                        string k = lines[i].Substring(0, colon).Trim();
                        string v = lines[i].Substring(colon + 1).Trim();
                        headers[k] = v;
                    }
                }

                string expectVal;
                if (headers.TryGetValue("Expect", out expectVal) &&
                    expectVal.IndexOf("100-continue", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    byte[] cont = Encoding.ASCII.GetBytes("HTTP/1.1 100 Continue\r\n\r\n");
                    cStream.Write(cont, 0, cont.Length);
                    cStream.Flush();
                }

                if (method == "GET" && target.StartsWith("/ocr-bridge/health", StringComparison.OrdinalIgnoreCase))
                {
                    string json = "{\"status\":\"ok\",\"bridge\":\"bggpt-ocr-proxy\",\"ocrReady\":" +
                                  (ocrReady ? "true" : "false") +
                                  ",\"ocrLang\":\"" + primaryLang +
                                  "\",\"visionReady\":" + (visionReady ? "true" : "false") +
                                  ",\"visionModel\":\"" + visionModelName.Replace("\"", "") +
                                  "\",\"upstreamPort\":" + upstreamPort + "}";
                    WriteSimpleJson(cStream, 200, "OK", json);
                    return;
                }

                byte[] body = new byte[0];
                string teVal;
                string clVal;
                if (headers.TryGetValue("Transfer-Encoding", out teVal) &&
                    teVal.IndexOf("chunked", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    body = ReadChunkedBody(cStream);
                }
                else if (headers.TryGetValue("Content-Length", out clVal))
                {
                    int cl;
                    if (int.TryParse(clVal.Trim(), out cl) && cl > 0 && cl <= 64 * 1024 * 1024)
                    {
                        body = ReadExact(cStream, cl);
                    }
                }

                bool isChat = (method == "POST") &&
                              (target.IndexOf("/chat/completions", StringComparison.OrdinalIgnoreCase) >= 0);
                if (isChat && body.Length > 0)
                {
                    string bodyStr = Encoding.UTF8.GetString(body);
                    if (bodyStr.IndexOf("image_url", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        bodyStr.IndexOf("data:image/", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        try
                        {
                            string rewritten = RewriteChatWithHybridAnalysis(bodyStr);
                            body = Encoding.UTF8.GetBytes(rewritten);
                        }
                        catch (Exception ex)
                        {
                            Log("Hybrid rewrite error: " + ex.Message);
                        }
                    }
                }

                bool isProps = (method == "GET") &&
                               (target.Equals("/props", StringComparison.OrdinalIgnoreCase) ||
                                target.StartsWith("/props?", StringComparison.OrdinalIgnoreCase));

                ForwardToUpstream(cStream, method, target, headers, body, isProps);
            }
        }
        catch (Exception ex)
        {
            Log("Client handler warning: " + ex.Message);
        }
        finally
        {
            try { client.Close(); } catch {}
        }
    }

    private string RewriteChatWithHybridAnalysis(string jsonBody)
    {
        JavaScriptSerializer ser = new JavaScriptSerializer();
        ser.MaxJsonLength = int.MaxValue;
        ser.RecursionLimit = 256;

        object rootObj = ser.DeserializeObject(jsonBody);
        Dictionary<string, object> root = rootObj as Dictionary<string, object>;
        if (root == null) return jsonBody;

        object msgsObj;
        if (!root.TryGetValue("messages", out msgsObj)) return jsonBody;
        IList messages = msgsObj as IList;
        if (messages == null) return jsonBody;

        bool modified = false;
        for (int i = 0; i < messages.Count; i++)
        {
            Dictionary<string, object> msg = messages[i] as Dictionary<string, object>;
            if (msg == null) continue;
            object contentObj;
            if (!msg.TryGetValue("content", out contentObj)) continue;
            IList parts = contentObj as IList;
            if (parts == null) continue;

            // Collect text first so visual intent detection knows what the user asked
            StringBuilder textSb = new StringBuilder();
            List<string> imageUrls = new List<string>();

            for (int j = 0; j < parts.Count; j++)
            {
                Dictionary<string, object> part = parts[j] as Dictionary<string, object>;
                if (part == null) continue;
                object typeObj;
                string pType = "";
                if (part.TryGetValue("type", out typeObj) && typeObj != null)
                {
                    pType = typeObj.ToString();
                }

                if (pType.Equals("text", StringComparison.OrdinalIgnoreCase) || part.ContainsKey("text"))
                {
                    object tObj;
                    if (part.TryGetValue("text", out tObj) && tObj != null)
                    {
                        if (textSb.Length > 0) textSb.Append("\n");
                        textSb.Append(tObj.ToString());
                    }
                }
                else if (pType.Equals("image_url", StringComparison.OrdinalIgnoreCase) ||
                         pType.Equals("input_image", StringComparison.OrdinalIgnoreCase) ||
                         part.ContainsKey("image_url"))
                {
                    string imgUrl = null;
                    object iuObj;
                    if (part.TryGetValue("image_url", out iuObj) && iuObj != null)
                    {
                        Dictionary<string, object> iuDict = iuObj as Dictionary<string, object>;
                        if (iuDict != null)
                        {
                            object uObj;
                            if (iuDict.TryGetValue("url", out uObj) && uObj != null)
                            {
                                imgUrl = uObj.ToString();
                            }
                        }
                        else
                        {
                            imgUrl = iuObj.ToString();
                        }
                    }
                    if (!string.IsNullOrEmpty(imgUrl))
                    {
                        imageUrls.Add(imgUrl);
                    }
                }
            }

            if (imageUrls.Count > 0)
            {
                string userText = textSb.ToString().Trim();
                StringBuilder finalContent = new StringBuilder();
                if (userText.Length > 0)
                {
                    finalContent.Append(userText);
                    finalContent.Append("\n\n");
                }
                else
                {
                    finalContent.Append("Опиши и анализирай прикачената снимка на български език:\n\n");
                }
                for (int k = 0; k < imageUrls.Count; k++)
                {
                    if (imageUrls.Count > 1)
                    {
                        finalContent.Append("--- Изображение ").Append(k + 1).Append(" ---\n");
                    }
                    try
                    {
                        finalContent.Append(AnalyzeImageDataUrl(imageUrls[k], userText));
                    }
                    catch (Exception ex)
                    {
                        finalContent.Append("[Грешка при обработка на изображението: " + ex.Message + "]");
                    }
                    if (k + 1 < imageUrls.Count) finalContent.Append("\n\n");
                }
                msg["content"] = finalContent.ToString();
                modified = true;
            }
            else if (textSb.Length > 0)
            {
                msg["content"] = textSb.ToString();
                modified = true;
            }
        }

        if (!modified) return jsonBody;
        return ser.Serialize(root);
    }

    private void ForwardToUpstream(
        NetworkStream clientStream,
        string method,
        string target,
        Dictionary<string, string> headers,
        byte[] body,
        bool rewriteProps)
    {
        using (TcpClient upstream = new TcpClient())
        {
            upstream.NoDelay = true;
            upstream.ReceiveTimeout = 300000;
            upstream.SendTimeout = 60000;
            try
            {
                upstream.Connect(IPAddress.Loopback, upstreamPort);
            }
            catch (Exception ex)
            {
                WriteSimpleJson(clientStream, 502, "Bad Gateway",
                    "{\"error\":{\"message\":\"Local BgGPT server on port " + upstreamPort + " is not ready: " +
                    ex.Message.Replace("\"", "'") + "\"}}");
                return;
            }

            using (NetworkStream upStream = upstream.GetStream())
            {
                StringBuilder reqSb = new StringBuilder();
                reqSb.Append(method).Append(" ").Append(target).Append(" HTTP/1.1\r\n");
                reqSb.Append("Host: 127.0.0.1:").Append(upstreamPort).Append("\r\n");

                foreach (KeyValuePair<string, string> kv in headers)
                {
                    string k = kv.Key;
                    if (k.Equals("Host", StringComparison.OrdinalIgnoreCase) ||
                        k.Equals("Connection", StringComparison.OrdinalIgnoreCase) ||
                        k.Equals("Content-Length", StringComparison.OrdinalIgnoreCase) ||
                        k.Equals("Transfer-Encoding", StringComparison.OrdinalIgnoreCase) ||
                        k.Equals("Expect", StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }
                    if (rewriteProps && k.Equals("Accept-Encoding", StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }
                    reqSb.Append(k).Append(": ").Append(kv.Value).Append("\r\n");
                }

                if (rewriteProps)
                {
                    reqSb.Append("Accept-Encoding: identity\r\n");
                }
                if (body.Length > 0 || method == "POST" || method == "PUT" || method == "PATCH")
                {
                    reqSb.Append("Content-Length: ").Append(body.Length).Append("\r\n");
                }
                reqSb.Append("Connection: close\r\n\r\n");

                byte[] reqHdrBytes = Encoding.ASCII.GetBytes(reqSb.ToString());
                upStream.Write(reqHdrBytes, 0, reqHdrBytes.Length);
                if (body.Length > 0)
                {
                    upStream.Write(body, 0, body.Length);
                }
                upStream.Flush();

                if (rewriteProps)
                {
                    byte[] upHdrBytes = ReadHeaderBytes(upStream);
                    string upHdrText = Encoding.ASCII.GetString(upHdrBytes);
                    string[] upLines = upHdrText.Split(new string[] { "\r\n" }, StringSplitOptions.None);
                    bool isChunked = upHdrText.IndexOf("Transfer-Encoding: chunked", StringComparison.OrdinalIgnoreCase) >= 0;

                    byte[] upBody;
                    if (isChunked)
                    {
                        upBody = ReadChunkedBody(upStream);
                    }
                    else
                    {
                        MemoryStream ms = new MemoryStream();
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = upStream.Read(buf, 0, buf.Length)) > 0)
                        {
                            ms.Write(buf, 0, n);
                        }
                        upBody = ms.ToArray();
                    }

                    string json = Encoding.UTF8.GetString(upBody);
                    json = Regex.Replace(json, "\"vision\"\\s*:\\s*false", "\"vision\":true", RegexOptions.IgnoreCase);
                    byte[] outBody = Encoding.UTF8.GetBytes(json);

                    StringBuilder respHdr = new StringBuilder();
                    respHdr.Append(upLines.Length > 0 && upLines[0].Length > 0 ? upLines[0] : "HTTP/1.1 200 OK").Append("\r\n");
                    for (int i = 1; i < upLines.Length; i++)
                    {
                        if (string.IsNullOrEmpty(upLines[i])) break;
                        if (upLines[i].StartsWith("Content-Length:", StringComparison.OrdinalIgnoreCase) ||
                            upLines[i].StartsWith("Transfer-Encoding:", StringComparison.OrdinalIgnoreCase) ||
                            upLines[i].StartsWith("Connection:", StringComparison.OrdinalIgnoreCase))
                        {
                            continue;
                        }
                        respHdr.Append(upLines[i]).Append("\r\n");
                    }
                    respHdr.Append("Content-Length: ").Append(outBody.Length).Append("\r\n");
                    respHdr.Append("Connection: close\r\n\r\n");

                    byte[] rhb = Encoding.ASCII.GetBytes(respHdr.ToString());
                    clientStream.Write(rhb, 0, rhb.Length);
                    clientStream.Write(outBody, 0, outBody.Length);
                    clientStream.Flush();
                }
                else
                {
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = upStream.Read(buf, 0, buf.Length)) > 0)
                    {
                        clientStream.Write(buf, 0, n);
                        clientStream.Flush();
                    }
                }
            }
        }
    }

    public void Dispose()
    {
        running = false;
        try { if (listener != null) listener.Stop(); } catch {}
        try { jobSignal.Set(); } catch {}
    }
}
'@

Write-BridgeLog ("Starting BgGPT Hybrid OCR + SmolVLM2 Bridge on http://127.0.0.1:$ListenPort -> http://127.0.0.1:$UpstreamPort ...")
$proxy = New-Object BgGptHybridProxy(
  $ListenPort, $UpstreamPort,
  $script:OcrReady, $script:PrimaryLangTag,
  $script:VisionReady, $script:MtmdCliPath, $script:VisionModelPath, $script:VisionMmprojPath, $script:VisionModelName
)
try {
  $proxy.Start()
  Write-BridgeLog '[OK] Hybrid Bridge listening on port 8080 (Windows OCR + SmolVLM2 Vision + SSE streaming).'
  while ($true) {
    $logMsg = $null
    while ($proxy.TryDequeueLog([ref]$logMsg)) {
      Write-BridgeLog $logMsg
    }

    $job = $proxy.WaitForOcrJob(250)
    if ($null -ne $job) {
      try {
        $job.ResultText = Invoke-WinRtOcrFile $job.TempPngPath
      } catch {
        $job.ErrorMessage = $_.Exception.Message
        Write-BridgeLog ('OCR job error: ' + $job.ErrorMessage)
      } finally {
        $job.Done.Set()
      }
    }
  }
} finally {
  $proxy.Dispose()
  Write-BridgeLog 'Hybrid Bridge stopped.'
}
