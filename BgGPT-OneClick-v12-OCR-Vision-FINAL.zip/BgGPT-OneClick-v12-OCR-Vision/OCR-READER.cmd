@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0BgGPT-OCR-GUI.ps1"
if errorlevel 1 (
  echo.
  echo OCR Reader closed with an error. / OCR chetecyt priklyuchi s greshka.
  pause
)
endlocal
