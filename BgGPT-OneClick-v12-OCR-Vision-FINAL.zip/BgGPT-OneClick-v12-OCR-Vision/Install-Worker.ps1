﻿# BgGPT Local Universal v12 Hybrid (OCR + PDF + SmolVLM2-2.2B Vision) - isolated worker.
# Windows PowerShell 5.1 x64, zero Python, 100% local inference.
param(
  [ValidateSet('bg','en')][string]$Language='bg',
  [switch]$ForceModel,
  [Parameter(Mandatory=$true)][ValidatePattern('^[0-9a-f]{32}$')][string]$RunId
)
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
$Root=Join-Path $env:LOCALAPPDATA 'BgGPT-Local'
$Dl=Join-Path $Root 'downloads'
$Models=Join-Path $Root 'models'
$VisionDir=Join-Path $Models 'smolvlm2'
$Logs=Join-Path $Root 'logs'
$StatusFile=Join-Path $Root ('install-status-'+$RunId+'.json')
$CancelFile=Join-Path $Root ('install-cancel-'+$RunId+'.flag')
$SourceDir=Split-Path -Parent $MyInvocation.MyCommand.Path

# Official INSAIT BgGPT Gemma 3 4B IT Q6_K GGUF
$ModelName='BgGPT-Gemma-3-4B-IT-Q6_K.gguf'
$ModelPath=Join-Path $Models $ModelName
$ModelSize=3184198912L
$ModelSha='3480257711e857221154cae13e6ac4bfe23c089214c21cff2ee633ec5063b979'
$ModelUrl='https://huggingface.co/INSAIT-Institute/BgGPT-Gemma-3-4B-IT-GGUF/resolve/main/BgGPT-Gemma-3-4B-IT-Q6_K.gguf'

# Official ggml-org SmolVLM2-2.2B-Instruct GGUF (exact pinned filenames & verified SHA-256)
$SmolMainName='SmolVLM2-2.2B-Instruct-Q4_K_M.gguf'
$SmolMainPath=Join-Path $VisionDir $SmolMainName
$SmolMainSize=1112602656L
$SmolMainSha='0cf76814555b8665149075b74ab6b5c1d428ea1d3d01c1918c12012e8d7c9f58'
$SmolMainUrl='https://huggingface.co/ggml-org/SmolVLM2-2.2B-Instruct-GGUF/resolve/main/SmolVLM2-2.2B-Instruct-Q4_K_M.gguf'

$SmolMmName='mmproj-SmolVLM2-2.2B-Instruct-Q8_0.gguf'
$SmolMmPath=Join-Path $VisionDir $SmolMmName
$SmolMmSize=593000000L
$SmolMmSha='ae07ea1facd07dd3230c4483b63e8cda96c6944ad2481f33d531f79e892dd024'
$SmolMmUrl='https://huggingface.co/ggml-org/SmolVLM2-2.2B-Instruct-GGUF/resolve/main/mmproj-SmolVLM2-2.2B-Instruct-Q8_0.gguf'

$Release='https://github.com/ggml-org/llama.cpp/releases/download/b12651/'
$BaseExe='llama-b12651-bin-win-'
$AnythingUrl='https://cdn.anythingllm.com/latest/AnythingLLMDesktop.exe'

$script:Stages=@([double]0,[double]0,[double]0,[double]0)
$script:Labels=@('','','','')
$script:Note=''
$script:Kind='running'
$script:Backend=''
$script:Gpu=''
$script:AnyExe=''
foreach($d in @($Root,$Dl,$Models,$VisionDir,$Logs)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
if (Test-Path $CancelFile) { Remove-Item $CancelFile -Force }

function Say([string]$bg,[string]$en) { if ($Language -eq 'bg') {$bg} else {$en} }
function Check-Cancel { if(Test-Path -LiteralPath $CancelFile){ throw 'Cancelled by the user / Отказано от потребителя.' } }

function Publish([string]$note='', [int]$stage=-1, [double]$percentage=-1, [string]$kind='running') {
  if ($stage -ge 0 -and $stage -lt 4 -and $percentage -ge 0) {
    $script:Stages[$stage]=[Math]::Round([Math]::Max(0.0,[Math]::Min(100.0,$percentage)),2)
  }
  if ($note) { $script:Note=$note; if($stage -ge 0 -and $stage -lt 4){$script:Labels[$stage]=$note} }
  $script:Kind=$kind
  $total=[Math]::Round(([double](($script:Stages | Measure-Object -Sum).Sum) / 4.0),2)
  $json=@{ kind=$script:Kind; stage=$stage; progress=@($script:Stages); labels=@($script:Labels);
    total=$total; note=$script:Note; backend=$script:Backend; gpu=$script:Gpu;
    runId=$RunId; date=[DateTime]::UtcNow.ToString('o') } | ConvertTo-Json -Compress -Depth 4
  $bytes=[Text.Encoding]::UTF8.GetBytes($json)
  for($retry=0;$retry -lt 12;$retry++) {
    $stream=$null
    try {
      $stream=[IO.FileStream]::new($StatusFile,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::Write,
        ([IO.FileShare]([int][IO.FileShare]::ReadWrite -bor [int][IO.FileShare]::Delete)))
      $stream.SetLength(0)
      $stream.Write($bytes,0,$bytes.Length)
      $stream.Flush()
      return
    } catch [IO.IOException] {
      if($retry -eq 11){throw}
      Start-Sleep -Milliseconds 60
    } finally {if($stream){$stream.Dispose()}}
  }
}

function Record([string]$message){
  $stamp='['+[DateTime]::Now.ToString('HH:mm:ss')+'] '+$message
  Add-Content -LiteralPath (Join-Path $Logs 'install.log') -Value $stamp -Encoding UTF8
}

function Verified([string]$path,[long]$min,[string]$sha='') {
  if(-not(Test-Path -LiteralPath $path -PathType Leaf)){return $false}
  if((Get-Item -LiteralPath $path).Length -lt $min){return $false}
  if($sha){return ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ieq $sha)}
  return $true
}

function Is-GgufFile([string]$path,[long]$minBytes) {
  if(-not(Test-Path -LiteralPath $path -PathType Leaf)){return $false}
  if((Get-Item -LiteralPath $path).Length -lt $minBytes){return $false}
  $fs=[IO.File]::OpenRead($path)
  try{
    $b=New-Object byte[] 4
    [void]$fs.Read($b,0,4)
    return ([Text.Encoding]::ASCII.GetString($b) -eq 'GGUF')
  }finally{$fs.Dispose()}
}

function Download([string]$url,[string]$dest,[long]$size,[long]$min,[string]$sha,[int]$stage,[double]$startPct=0,[double]$endPct=100) {
  Check-Cancel
  if(Verified $dest $min $sha){Publish (Say 'Наличен проверен файл' 'Verified file found') $stage $endPct; return}
  $partial=$dest+'.part'
  if(Test-Path -LiteralPath $partial) {
    $probe=$null
    try {
      $probe=[IO.FileStream]::new($partial,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    } catch [IO.IOException] {
      throw (Say 'Файлът се използва от друга инсталация. Затворете предишния инсталатор и опитайте отново, без да триете .part.' 'The partial download is in use by another installer. Close the older installer and retry; do not delete .part.')
    } finally { if($probe){$probe.Dispose()} }
  }
  if(Verified $partial $min $sha){
    Move-Item -LiteralPath $partial -Destination $dest -Force
    Publish (Say 'Възстановено проверено изтегляне' 'Recovered verified download') $stage $endPct
    return
  }
  $curl=Join-Path $env:SystemRoot 'System32\curl.exe'
  if(-not (Test-Path $curl)){throw 'curl.exe is missing. Windows 10/11 with curl.exe is required.'}
  $args=@('--location','--fail','--retry','3','--retry-delay','3','--connect-timeout','30','--silent','--show-error')
  if((Test-Path $partial) -and ((Get-Item $partial).Length -gt 0)){$args+=@('--continue-at','-')}
  $args+=@('--output',('"'+$partial+'"'),('"'+$url+'"'))
  $fileName=[IO.Path]::GetFileName($dest)
  Publish ((Say 'Изтегляне' 'Downloading')+': '+$fileName) $stage $startPct
  Record ('Official download: '+$url)
  $p=Start-Process -FilePath $curl -ArgumentList ($args -join ' ') -PassThru -WindowStyle Hidden
  while(-not $p.HasExited){
    if(Test-Path $CancelFile){Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue; Check-Cancel}
    if(Test-Path $partial){
      $bytes=(Get-Item $partial).Length
      if($size -gt 0){
        $frac=[Math]::Min(0.99,[Math]::Max(0.0,($bytes*1.0)/$size))
        $pct=[Math]::Round(($startPct+$frac*($endPct-$startPct)),2)
        $numeric=if($Language -eq 'bg'){$pct.ToString('N2',[Globalization.CultureInfo]::GetCultureInfo('bg-BG'))}else{$pct.ToString('N2',[Globalization.CultureInfo]::InvariantCulture)}
        Publish (('{0}: {1:N1} / {2:N1} MB ({3}%)' -f (Say 'Изтеглено' 'Downloaded'),($bytes/1MB),($size/1MB),$numeric)) $stage $pct
      } else {
        Publish (('{0}: {1:N1} MB' -f (Say 'Изтеглено' 'Downloaded'),($bytes/1MB))) $stage -1
      }
    }
    Start-Sleep -Milliseconds 350
    $p.Refresh()
  }
  if($p.ExitCode -ne 0){throw ('Download failed / Грешка при изтегляне: '+$fileName+', curl exit '+$p.ExitCode)}
  if(-not(Verified $partial $min $sha)){throw ('Integrity check failed / Грешка при проверка: '+$fileName)}
  Move-Item -LiteralPath $partial -Destination $dest -Force
  Publish (Say 'Проверен файл' 'Verified download') $stage $endPct
}

function Runtime-Ready([string]$path,[string]$backend){
  $server=Join-Path $path 'llama-server.exe'
  $marker=Join-Path $path '.b12651-ready'
  if(-not (Test-Path -LiteralPath $server -PathType Leaf)){return $false}
  if(-not (Test-Path -LiteralPath $marker -PathType Leaf)){return $false}
  if((Get-Content -LiteralPath $marker -Raw).Trim() -ne $backend){return $false}
  if($backend -eq 'cuda' -and -not (Test-Path -LiteralPath (Join-Path $path 'cublas64_12.dll') -PathType Leaf)){return $false}
  return $true
}

function Runtime-Destination([string]$backend){
  $base=Join-Path $Root ('bin-'+$backend+'-b12651-v11')
  if(Runtime-Ready $base $backend){return $base}
  if(Test-Path -LiteralPath $base){
    foreach($candidate in @(Get-ChildItem -LiteralPath $Root -Directory -Filter ('bin-'+$backend+'-b12651-v11-*') | Sort-Object LastWriteTime -Descending)){
      if(Runtime-Ready $candidate.FullName $backend){return $candidate.FullName}
    }
    $base=$base+'-'+$RunId
  }
  return $base
}

function Commit-Runtime([string]$path,[string]$backend){
  if(-not(Test-Path -LiteralPath (Join-Path $path 'llama-server.exe') -PathType Leaf)){throw 'Runtime executable missing.'}
  Set-Content -LiteralPath (Join-Path $path '.b12651-ready') -Value $backend -Encoding ASCII
}

function Unpack([string]$zip,[string]$dest){
  $tmp=$dest+'-unpack-'+$RunId
  if(Test-Path -LiteralPath $dest){throw 'Runtime destination already exists; no files were overwritten.'}
  New-Item -Path $tmp -ItemType Directory -Force | Out-Null
  Expand-Archive -LiteralPath $zip -DestinationPath $tmp -Force
  $server=Get-ChildItem $tmp -Recurse -Filter 'llama-server.exe' -File | Select-Object -First 1
  if(-not $server){throw ('llama-server.exe missing in '+$zip)}
  New-Item -ItemType Directory -Path $dest -Force | Out-Null
  Copy-Item -Path (Join-Path $server.Directory.FullName '*') -Destination $dest -Recurse -Force
  Remove-Item $tmp -Recurse -Force
}

function Find-Anything {
  foreach($path in @(
    (Join-Path $env:LOCALAPPDATA 'Programs\AnythingLLM\AnythingLLM.exe'),
    (Join-Path $env:LOCALAPPDATA 'Programs\AnythingLLM\AnythingLLMDesktop.exe'),
    (Join-Path $env:LOCALAPPDATA 'Programs\anythingllm-desktop\AnythingLLMDesktop.exe'),
    (Join-Path $env:LOCALAPPDATA 'Programs\anythingllm-desktop\AnythingLLM.exe')
  )){if(Test-Path $path -PathType Leaf){return $path}}
  try{
    $uninst=Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue
    foreach($app in @($uninst | Where-Object { $_.DisplayName -like '*AnythingLLM*' -and $_.InstallLocation })){
      foreach($name in @('AnythingLLM.exe','AnythingLLMDesktop.exe')){
        $path=Join-Path ([string]$app.InstallLocation) $name
        if(Test-Path $path -PathType Leaf){return $path}
      }
    }
  }catch{}
  return $null
}

function Create-Shortcuts {
  $desktop=[Environment]::GetFolderPath('DesktopDirectory')
  if(-not $desktop -or -not (Test-Path $desktop)){return}
  $shell=New-Object -ComObject WScript.Shell
  $link=$shell.CreateShortcut((Join-Path $desktop 'BgGPT Local - Start.lnk'))
  $link.TargetPath=(Join-Path $Root 'START.cmd')
  $link.WorkingDirectory=$Root
  $link.Description='BgGPT Local - Bulgarian AI with Hybrid OCR & SmolVLM2 Vision'
  $link.Save()

  $ocrLink=$shell.CreateShortcut((Join-Path $desktop 'BgGPT Local - OCR.lnk'))
  $ocrLink.TargetPath=(Join-Path $Root 'OCR-READER.cmd')
  $ocrLink.WorkingDirectory=$Root
  $ocrLink.Description='BgGPT Local OCR - Offline Image & Scanned PDF Book Reader'
  $ocrLink.Save()
}

function Stop-OwnProcessesForUpgrade([string]$runtimeDir,[string]$cpuDir,[string]$modelPath){
  $allowed=@((Join-Path $runtimeDir 'llama-server.exe'),(Join-Path $cpuDir 'llama-server.exe'))
  foreach($port in @(8080, 8081)){
    $ids=@(Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique)
    foreach($idVal in $ids){
      $p=Get-CimInstance Win32_Process -Filter "ProcessId=$idVal" -ErrorAction SilentlyContinue
      if(-not $p){continue}
      $exe=[string]$p.ExecutablePath
      $cmd=[string]$p.CommandLine
      $isOwnLlama=($allowed -contains $exe) -and ($cmd.IndexOf($modelPath,[StringComparison]::OrdinalIgnoreCase) -ge 0)
      $isOwnBridge=($cmd.IndexOf('BgGPT-OCR-Bridge.ps1',[StringComparison]::OrdinalIgnoreCase) -ge 0)
      if($isOwnLlama -or $isOwnBridge){
        Record ('Stopping existing BgGPT process PID '+$idVal+' on port '+$port+' for clean bridge startup.')
        Stop-Process -Id $idVal -Force -ErrorAction SilentlyContinue
      }
    }
  }
  Start-Sleep -Seconds 2
}

function Verify-HybridOcrAndVision([string]$alias){
  Add-Type -AssemblyName System.Drawing

  # Test 1: Text image (fast Windows OCR path)
  $bmp1=New-Object Drawing.Bitmap 480,180
  $g1=[Drawing.Graphics]::FromImage($bmp1)
  $font=New-Object Drawing.Font('Arial',42,[Drawing.FontStyle]::Bold)
  $ms1=New-Object IO.MemoryStream
  try{
    $g1.Clear([Drawing.Color]::White)
    $g1.DrawString('BGGPT 2026',$font,[Drawing.Brushes]::Black,55,55)
    $bmp1.Save($ms1,[Drawing.Imaging.ImageFormat]::Png)
    $b64_1=[Convert]::ToBase64String($ms1.ToArray())
  }finally{$font.Dispose();$g1.Dispose();$bmp1.Dispose();$ms1.Dispose()}

  $body1=@{
    model=$alias; temperature=0; max_tokens=32;
    messages=@(@{
      role='user';
      content=@(
        @{type='text'; text='What year number is written in the attached image? Answer with the 4-digit year.'},
        @{type='image_url'; image_url=@{url=('data:image/png;base64,'+$b64_1)}}
      )
    })
  } | ConvertTo-Json -Depth 10 -Compress

  $res1=Invoke-RestMethod -Uri 'http://127.0.0.1:8080/v1/chat/completions' -Method Post -ContentType 'application/json' -Body $body1 -TimeoutSec 90
  $ans1=[string]$res1.choices[0].message.content
  Record ('Hybrid Test 1 (OCR Text PNG) response: '+$ans1)

  # Test 2: Pure visual image with ZERO text (SmolVLM2-2.2B Vision path: large red circle on white background)
  $bmp2=New-Object Drawing.Bitmap 320,320
  $g2=[Drawing.Graphics]::FromImage($bmp2)
  $ms2=New-Object IO.MemoryStream
  try{
    $g2.Clear([Drawing.Color]::White)
    $g2.FillEllipse([Drawing.Brushes]::Red, 60, 60, 200, 200)
    $bmp2.Save($ms2,[Drawing.Imaging.ImageFormat]::Png)
    $b64_2=[Convert]::ToBase64String($ms2.ToArray())
  }finally{$g2.Dispose();$bmp2.Dispose();$ms2.Dispose()}

  $body2=@{
    model=$alias; temperature=0; max_tokens=48;
    messages=@(@{
      role='user';
      content=@(
        @{type='text'; text='Какъв цвят и каква геометрична фигура виждаш на тази снимка? Отговори кратко.'},
        @{type='image_url'; image_url=@{url=('data:image/png;base64,'+$b64_2)}}
      )
    })
  } | ConvertTo-Json -Depth 10 -Compress

  $res2=Invoke-RestMethod -Uri 'http://127.0.0.1:8080/v1/chat/completions' -Method Post -ContentType 'application/json' -Body $body2 -TimeoutSec 180
  $ans2=[string]$res2.choices[0].message.content
  Record ('Hybrid Test 2 (SmolVLM2 Red Circle PNG) response: '+$ans2)

  return @{
    ocrOk=($ans1 -match '2026');
    visionOk=($ans2 -match 'червен|red|кръг|окръжност|circle')
  }
}

$installMutex=$null
$mutexOwned=$false
try{
  $installMutex=[Threading.Mutex]::new($false,'Local\BgGPTLocalOneClickInstall')
  try {$mutexOwned=$installMutex.WaitOne(0)} catch [Threading.AbandonedMutexException] {$mutexOwned=$true}
  if(-not $mutexOwned){throw (Say 'Друга инсталация вече работи. Не пускайте второ изтегляне.' 'Another installation is running. Do not start a second download.')}

  # STAGE 1: Hardware & llama.cpp b12651 runtime
  Publish (Say 'Проверка на компютъра' 'Detecting hardware') 0 0
  if (-not [Environment]::Is64BitOperatingSystem -or [Environment]::OSVersion.Version.Major -lt 10){throw 'Windows 10/11 x64 is required.'}
  $cards=@(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | ForEach-Object {[string]$_.Name})
  $script:Gpu=($cards -join '; ')
  if(-not $script:Gpu){$script:Gpu='Unspecified GPU'}
  $script:Backend='cpu'
  $oldAmd=$false
  if(@($cards | Where-Object {$_ -match 'NVIDIA.*(RTX|GTX (10|16|20|30|40|50))|GeForce RTX|RTX \d{4}' }).Count -gt 0){$script:Backend='cuda'}
  elseif(@($cards | Where-Object {$_ -match 'Radeon|AMD|Intel.*Arc'}).Count -gt 0){$script:Backend='vulkan'}
  if($script:Backend -eq 'vulkan' -and $script:Gpu -match 'R9\s*(290|390)|Radeon\s*Pro\s*580'){ $oldAmd=$true }
  Record ('Detected: '+$script:Gpu+' | selected '+$script:Backend)
  Publish (Say ('Открит хардуер: '+$script:Gpu) ('Detected: '+$script:Gpu)) 0 4

  $cpuZip=$BaseExe+'cpu-x64.zip'
  $cpuZipPath=Join-Path $Dl $cpuZip
  $cpuDir=Runtime-Destination 'cpu'
  if(-not(Runtime-Ready $cpuDir 'cpu')){
    Download ($Release+$cpuZip) $cpuZipPath 0 1000000 'b2d794fa7587aba29f654d717ff9b73e31caeabf50a7766692903008bbe0855d' 0 5 34
    Publish (Say 'Подготовка на CPU резервен режим' 'Preparing safe CPU fallback') 0 35
    Unpack $cpuZipPath $cpuDir
    Commit-Runtime $cpuDir 'cpu'
  }
  Publish (Say 'CPU резервен режим е готов' 'CPU fallback ready') 0 45

  $backendDir=$cpuDir
  if($script:Backend -ne 'cpu'){
    $pkg=if($script:Backend -eq 'cuda'){'llama-b12651-bin-win-cuda-12.4-x64.zip'}else{'llama-b12651-bin-win-vulkan-x64.zip'}
    $destDir=Runtime-Destination $script:Backend
    $runtimeReady=Runtime-Ready $destDir $script:Backend
    if(-not $runtimeReady){
      $pkgPath=Join-Path $Dl $pkg
      $hash=if($script:Backend -eq 'vulkan'){'e58fa9a137d8046c69334005ad6fb3e904ddc7e56f2a61ad1b844335826ef3f4'}else{'1a6c090f76fab41260b5b7597c6fb1add1fad2efaac692ae2673a22366220a29'}
      Download ($Release+$pkg) $pkgPath 0 1000000 $hash 0 45 83
      Publish (Say 'Разархивиране на GPU двигателя' 'Extracting GPU runtime') 0 84
      Unpack $pkgPath $destDir
    }
    if(-not $runtimeReady -and $script:Backend -eq 'cuda'){
      $dllPkg='cudart-llama-bin-win-cuda-12.4-x64.zip'
      $dllZip=Join-Path $Dl $dllPkg
      if(-not(Test-Path (Join-Path $destDir 'cublas64_12.dll'))){
        Download ($Release+$dllPkg) $dllZip 0 1000000 '8c79a9b226de4b3cacfd1f83d24f962d0773be79f1e7b75c6af4ded7e32ae1d6' 0 84 94
        $dllTmp=Join-Path $Root ('cuda-tmp-'+$RunId)
        Expand-Archive -LiteralPath $dllZip -DestinationPath $dllTmp -Force
        $dlls=Get-ChildItem $dllTmp -Recurse -File | Where-Object {$_.Extension -eq '.dll'}
        if(-not @($dlls).Count){throw 'No CUDA libraries found in official archive.'}
        foreach($d in $dlls){Copy-Item -LiteralPath $d.FullName -Destination (Join-Path $destDir $d.Name) -Force}
        Remove-Item $dllTmp -Recurse -Force
      }
    }
    if(-not $runtimeReady){Commit-Runtime $destDir $script:Backend}
    $backendDir=$destDir
  }
  Publish ((Say 'AI двигател:' 'Runtime:')+' '+$script:Backend) 0 100
  Check-Cancel

  # STAGE 2: Official INSAIT BgGPT Q6_K (0% -> 64%) + SmolVLM2-2.2B Vision Helper (64% -> 100%)
  Publish (Say 'Проверка на BgGPT (INSAIT)...' 'Checking INSAIT BgGPT...') 1 0
  if($ForceModel -or -not(Verified $ModelPath 3100000000L $ModelSha)){
    if($ForceModel -and (Test-Path $ModelPath)){
      $fresh=Join-Path $Dl ('fresh-'+$ModelName)
      if(Test-Path $fresh){Remove-Item $fresh -Force}
      Download $ModelUrl $fresh $ModelSize 3100000000L $ModelSha 1 0 64
      Copy-Item -LiteralPath $fresh -Destination $ModelPath -Force
      Remove-Item $fresh -Force
    }else{Download $ModelUrl $ModelPath $ModelSize 3100000000L $ModelSha 1 0 64}
  }else{
    Record 'Reusing verified INSAIT GGUF model'
    Publish (Say 'Проверен BgGPT е наличен (повторно използване)' 'Verified BgGPT already installed (reusing)') 1 64
  }
  if(-not(Verified $ModelPath 3100000000L $ModelSha)){throw 'INSAIT model verification failed'}
  Check-Cancel

  Publish (Say 'Проверка на SmolVLM2-2.2B Vision (1,70 GB)...' 'Checking SmolVLM2-2.2B Vision (1.70 GB)...') 1 65
  $visionModelLocal=$SmolMainPath
  $visionMmprojLocal=$SmolMmPath
  if($ForceModel -and (Test-Path -LiteralPath $visionModelLocal)){ Remove-Item -LiteralPath $visionModelLocal -Force }
  if($ForceModel -and (Test-Path -LiteralPath $visionMmprojLocal)){ Remove-Item -LiteralPath $visionMmprojLocal -Force }

  Download $SmolMainUrl $visionModelLocal $SmolMainSize 1110000000L $SmolMainSha 1 66 88
  Check-Cancel
  Download $SmolMmUrl $visionMmprojLocal $SmolMmSize 550000000L $SmolMmSha 1 88 100
  if(-not(Verified $visionModelLocal 1110000000L $SmolMainSha)){throw 'SmolVLM2 main model SHA-256 verification failed'}
  if(-not(Verified $visionMmprojLocal 550000000L $SmolMmSha)){throw 'SmolVLM2 mmproj SHA-256 verification failed'}
  Publish (Say 'BgGPT и SmolVLM2-2.2B Vision са проверени (SHA-256)' 'BgGPT and SmolVLM2-2.2B Vision verified (SHA-256)') 1 100
  Check-Cancel

  # STAGE 3: AnythingLLM Desktop
  Publish (Say 'Проверка на AnythingLLM' 'Checking AnythingLLM') 2 0
  $script:AnyExe=Find-Anything
  if(-not $script:AnyExe){
    $setup=Join-Path $Dl 'AnythingLLMDesktop.exe'
    Download $AnythingUrl $setup 0 100000000 '' 2 0 90
    Publish (Say 'Инсталиране на AnythingLLM' 'Installing AnythingLLM') 2 95
    $installer=Start-Process -FilePath $setup -ArgumentList '/S' -PassThru
    while(-not $installer.HasExited){Check-Cancel; Start-Sleep -Milliseconds 500; $installer.Refresh()}
    if($installer.ExitCode -ne 0){throw ('AnythingLLM installer exit '+$installer.ExitCode)}
    $script:AnyExe=Find-Anything
    if(-not $script:AnyExe){Record 'AnythingLLM installer finished but executable path not found.'; Publish (Say 'AnythingLLM: инсталирано, но пътят не е открит' 'AnythingLLM: installer finished, executable not located') 2 98}
  }
  Publish (Say 'AnythingLLM обработен' 'AnythingLLM step completed') 2 100
  Check-Cancel

  # STAGE 4: Deploy Hybrid Bridge + PDF OCR + Run Dual Image Tests (OCR + SmolVLM2 Photo)
  Publish (Say 'Инсталиране на хибридния OCR + Vision мост...' 'Installing Hybrid OCR + Vision Bridge...') 3 10
  Stop-OwnProcessesForUpgrade $backendDir $cpuDir $ModelPath

  foreach($name in @('START.cmd','CONFIGURE.cmd','OCR-READER.cmd','Start-BgGPT.ps1','BgGPT-OCR-Bridge.ps1','BgGPT-OCR-GUI.ps1','Convert-ScannedPdfToMarkdown.ps1','CONFIGURATION-BG-EN.txt','NOTICE.txt','README_BG.md','README_EN.md')){
    Copy-Item -LiteralPath (Join-Path $SourceDir $name) -Destination (Join-Path $Root $name) -Force
  }
  $config=@{
    backend=$script:Backend; legacyAmd=$oldAmd; gpu=$script:Gpu; runtime=$backendDir; cpuRuntime=$cpuDir;
    model=$ModelPath; visionModel=$visionModelLocal; visionMmproj=$visionMmprojLocal;
    anything=$script:AnyExe; modelAlias=$ModelName; contextSize=4096;
    publicPort=8080; backendPort=8081; ocrBridge=$true; hybridVision=$true; version='v12-hybrid-ocr-vision'
  }
  [IO.File]::WriteAllText((Join-Path $Root 'config.json'),($config|ConvertTo-Json -Depth 4),[Text.Encoding]::UTF8)
  Create-Shortcuts

  Publish (Say 'Пускане на BgGPT (8081) и хибридния мост (8080)...' 'Starting BgGPT (8081) and Hybrid Bridge (8080)...') 3 30
  $run=Start-Process -FilePath (Join-Path $Root 'CONFIGURE.cmd') -WorkingDirectory $Root -PassThru
  $ready=$false
  for($i=0;$i -lt 120;$i++){
    Check-Cancel
    try{
      $bh=Invoke-RestMethod -Uri 'http://127.0.0.1:8080/ocr-bridge/health' -TimeoutSec 2
      $m=Invoke-RestMethod -Uri 'http://127.0.0.1:8080/v1/models' -TimeoutSec 2
      if(($bh.status -eq 'ok') -and (@($m.data | Where-Object {([string]$_.id).EndsWith($ModelName,[StringComparison]::OrdinalIgnoreCase)}).Count -gt 0)){
        $ready=$true; break
      }
    }catch{}
    Start-Sleep -Milliseconds 700
  }
  if(-not $ready){throw 'Hybrid Bridge or BgGPT engine did not become ready. See logs\ocr-bridge.log and logs\server-error.log'}

  Publish (Say 'Тест 1 (OCR текст) и Тест 2 (SmolVLM2 снимка)...' 'Running Test 1 (OCR text) and Test 2 (SmolVLM2 photo)...') 3 65
  $testRes=Verify-HybridOcrAndVision $ModelName

  if($testRes.ocrOk -and $testRes.visionOk){
    $doneMsg=Say 'Готово! Преминаха и двата теста — текст (OCR) и снимки (SmolVLM2).' 'Ready! Passed both tests — text (OCR) and photos (SmolVLM2).'
  }elseif($testRes.visionOk){
    $doneMsg=Say 'Готово! SmolVLM2 разпозна снимката (проверете Windows OCR езиците).' 'Ready! SmolVLM2 recognized the photo (check Windows OCR languages).'
  }elseif($testRes.ocrOk){
    $doneMsg=Say 'Готово! OCR тестът мина (вижте logs\ocr-bridge.log за SmolVLM2).' 'Ready! OCR test passed (review logs\ocr-bridge.log for SmolVLM2).'
  }else{
    $doneMsg=Say 'Инсталацията завърши; проверете logs\ocr-bridge.log.' 'Installation finished; review logs\ocr-bridge.log.'
  }

  Publish $doneMsg 3 100 'done'
  Record ('BgGPT v12-hybrid-ocr-vision installed. ocrOk='+$testRes.ocrOk+' | visionOk='+$testRes.visionOk)
}catch{
  $message=$_.Exception.Message
  Record ('ERROR: '+$message)
  Publish $message -1 -1 'error'
  exit 1
} finally {
  if($mutexOwned -and $installMutex){try{$installMutex.ReleaseMutex()}catch{}}
  if($installMutex){$installMutex.Dispose()}
}
