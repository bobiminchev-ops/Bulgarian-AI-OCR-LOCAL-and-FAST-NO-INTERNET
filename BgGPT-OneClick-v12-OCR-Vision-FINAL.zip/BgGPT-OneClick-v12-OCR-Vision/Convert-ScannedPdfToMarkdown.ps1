﻿# BgGPT Local Offline PDF Book OCR Worker (Native Windows 10/11 Windows.Data.Pdf + Windows.Media.Ocr)
# Zero Python, 0 MB external tools, 100% offline. Writes page-marked Markdown (.ocr.md) ready for AnythingLLM RAG.
param(
  [Parameter(Mandatory=$true)][string]$PdfPath,
  [string]$OutPath = '',
  [string]$LanguageTag = 'bg-BG',
  [int]$StartPage = 1,
  [int]$EndPage = 0,
  [int]$TargetWidth = 2200,
  [string]$StatusFile = '',
  [string]$CancelFile = '',
  [ValidateSet('bg','en')][string]$UiLang = 'bg'
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime

function Say([string]$bg, [string]$en) { if ($UiLang -eq 'bg') { $bg } else { $en } }

function Write-Status([string]$kind, [int]$current, [int]$total, [double]$pct, [string]$note, [string]$outFile, [int]$pagesDone) {
  if (-not $StatusFile) { return }
  $payload = @{
    kind = $kind;
    current = $current;
    total = $total;
    percent = [Math]::Round([Math]::Max(0.0, [Math]::Min(100.0, $pct)), 2);
    note = $note;
    outPath = $outFile;
    pagesDone = $pagesDone;
    date = [DateTime]::UtcNow.ToString('o')
  } | ConvertTo-Json -Compress -Depth 4
  $bytes = [Text.Encoding]::UTF8.GetBytes($payload)
  for ($retry = 0; $retry -lt 10; $retry++) {
    $fs = $null
    try {
      $fs = [IO.FileStream]::new($StatusFile, [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::Write,
        ([IO.FileShare]([int][IO.FileShare]::ReadWrite -bor [int][IO.FileShare]::Delete)))
      $fs.SetLength(0)
      $fs.Write($bytes, 0, $bytes.Length)
      $fs.Flush()
      return
    } catch [IO.IOException] {
      if ($retry -eq 9) { return }
      Start-Sleep -Milliseconds 50
    } finally {
      if ($fs) { $fs.Dispose() }
    }
  }
}

$pagesDone = 0
try {
  if (-not (Test-Path -LiteralPath $PdfPath -PathType Leaf)) {
    throw (Say 'PDF файлът не е намерен.' 'PDF file was not found.')
  }

  $fullPdf = (Resolve-Path -LiteralPath $PdfPath).Path
  if ([string]::IsNullOrWhiteSpace($OutPath)) {
    $OutPath = [IO.Path]::ChangeExtension($fullPdf, '.ocr.md')
  }

  Write-Status 'running' 0 1 0 (Say 'Инициализиране на Windows PDF и OCR...' 'Initializing Windows PDF and OCR...') $OutPath 0

  # Load native Windows 10/11 WinRT PDF & OCR types
  $null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
  $null = [Windows.Storage.Streams.InMemoryRandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime]
  $null = [Windows.Data.Pdf.PdfDocument, Windows.Data.Pdf, ContentType = WindowsRuntime]
  $null = [Windows.Data.Pdf.PdfPageRenderOptions, Windows.Data.Pdf, ContentType = WindowsRuntime]
  $null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
  $null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
  $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
  $null = [Windows.Media.Ocr.OcrResult, Windows.Foundation, ContentType = WindowsRuntime]
  $null = [Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime]

  $asTaskOp = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
  })[0]

  $asTaskAct = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and (-not $_.IsGenericMethod) -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction'
  })[0]

  function Await-Op($task, [Type]$resultType) {
    $netTask = $asTaskOp.MakeGenericMethod($resultType).Invoke($null, @($task))
    return $netTask.GetAwaiter().GetResult()
  }

  function Await-Act($task) {
    $netTask = $asTaskAct.Invoke($null, @($task))
    $netTask.GetAwaiter().GetResult()
  }

  # Select primary and fallback Windows OCR engines
  $primary = $null
  if ($LanguageTag) {
    try {
      $primary = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new($LanguageTag))
    } catch {}
  }
  if ($null -eq $primary) {
    $primary = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
  }
  if ($null -eq $primary) {
    throw (Say 'Липсва инсталиран Windows OCR езиков пакет (добавете bg-BG или en-US).' 'No Windows OCR language pack installed (add bg-BG or en-US).')
  }

  $fallback = $null
  if (-not ($LanguageTag -like 'en*')) {
    try {
      $fallback = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new('en-US'))
    } catch {}
  }

  $maxDim = [int][Windows.Media.Ocr.OcrEngine]::MaxImageDimension
  if ($maxDim -le 0) { $maxDim = 2500 }

  # Open PDF document natively
  $storageFile = Await-Op ([Windows.Storage.StorageFile]::GetFileFromPathAsync($fullPdf)) ([Windows.Storage.StorageFile])
  try {
    $pdfDoc = Await-Op ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($storageFile)) ([Windows.Data.Pdf.PdfDocument])
  } catch {
    throw (Say 'PDF файлът не може да бъде отворен (възможно е да е защитен с парола или повреден).' 'Could not open PDF (it may be password-protected or corrupted).')
  }

  $totalDocPages = [int]$pdfDoc.PageCount
  if ($totalDocPages -le 0) {
    throw (Say 'PDF файлът не съдържа страници.' 'PDF file contains zero pages.')
  }

  $first = [Math]::Max(1, [Math]::Min($StartPage, $totalDocPages))
  $last = if ($EndPage -gt 0 -and $EndPage -le $totalDocPages) { $EndPage } else { $totalDocPages }
  if ($last -lt $first) { $last = $first }
  $spanCount = ($last - $first) + 1
  $bookTitle = [IO.Path]::GetFileName($fullPdf)
  $activeLang = [string]$primary.RecognizerLanguage.LanguageTag

  $outDir = Split-Path -Parent $OutPath
  if ($outDir -and -not (Test-Path -LiteralPath $outDir)) {
    New-Item -ItemType Directory -Path $outDir -Force | Out-Null
  }

  $sw = [Diagnostics.Stopwatch]::StartNew()
  $writer = New-Object IO.StreamWriter($OutPath, $false, [Text.UTF8Encoding]::new($false))
  $cancelled = $false
  try {
    $writer.WriteLine("# $bookTitle")
    $writer.WriteLine()
    $writer.WriteLine("> Local Offline Windows OCR ($activeLang) | Pages $first-$last of $totalDocPages")
    $writer.WriteLine()

    for ($p = $first; $p -le $last; $p++) {
      if ($CancelFile -and (Test-Path -LiteralPath $CancelFile)) {
        $cancelled = $true
        break
      }

      $idxInRange = ($p - $first) + 1
      $prePct = [Math]::Round((($idxInRange - 1) * 100.0) / $spanCount, 2)
      $stepNote = Say ("OCR на страница $p от $last ($bookTitle)...") ("Running OCR on page $p of $last ($bookTitle)...")
      Write-Status 'running' $p $last $prePct $stepNote $OutPath $pagesDone

      $page = $null
      $memStream = $null
      $softBmp = $null
      try {
        $page = $pdfDoc.GetPage([uint32]($p - 1))
        $opts = New-Object Windows.Data.Pdf.PdfPageRenderOptions

        $pageW = [double]$page.Size.Width
        $pageH = [double]$page.Size.Height
        if ($pageW -lt 1.0) { $pageW = 1.0 }
        $ratio = $pageH / $pageW

        $w = [Math]::Min($TargetWidth, $maxDim)
        $h = [int][Math]::Round($w * $ratio)
        if ($h -gt $maxDim) {
          $h = $maxDim
          $w = [int][Math]::Round($h / [Math]::Max(0.1, $ratio))
        }
        if ($w -lt 100) { $w = 100 }
        if ($h -lt 100) { $h = 100 }

        $opts.DestinationWidth = [uint32]$w
        $opts.DestinationHeight = [uint32]$h

        $memStream = New-Object Windows.Storage.Streams.InMemoryRandomAccessStream
        Await-Act ($page.RenderToStreamAsync($memStream, $opts))
        $memStream.Seek([uint64]0)

        $decoder = Await-Op ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($memStream)) ([Windows.Graphics.Imaging.BitmapDecoder])
        $softBmp = Await-Op ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])

        $ocrRes = Await-Op ($primary.RecognizeAsync($softBmp)) ([Windows.Media.Ocr.OcrResult])
        $lines = @($ocrRes.Lines | ForEach-Object { [string]$_.Text })
        $pageText = ($lines -join "`n").Trim()

        if ([string]::IsNullOrWhiteSpace($pageText) -and $null -ne $fallback) {
          $ocrRes2 = Await-Op ($fallback.RecognizeAsync($softBmp)) ([Windows.Media.Ocr.OcrResult])
          $lines2 = @($ocrRes2.Lines | ForEach-Object { [string]$_.Text })
          $pageText = ($lines2 -join "`n").Trim()
        }

        # Rejoin hyphenated words split across line breaks (Cyrillic & Latin) for cleaner RAG search
        if ($pageText) {
          $pageText = [regex]::Replace($pageText, '([А-Яа-яA-Za-z])-\s*\n\s*([а-яa-z])', '$1$2')
        } else {
          $pageText = '[Няма разпознат текст на тази страница]'
        }

        $writer.WriteLine("## [$bookTitle — Страница $p / $totalDocPages]")
        $writer.WriteLine()
        $writer.WriteLine($pageText)
        $writer.WriteLine()
        $writer.Flush()

        $pagesDone++
        $pct = [Math]::Round(($idxInRange * 100.0) / $spanCount, 2)
        $elapsed = [Math]::Round($sw.Elapsed.TotalSeconds, 1)
        $doneStep = Say ("Готова страница $p / $last ($pct% · ${elapsed} сек.)") ("Completed page $p / $last ($pct% · ${elapsed}s)")
        Write-Status 'running' $p $last $pct $doneStep $OutPath $pagesDone
        Write-Host ("PROGRESS|$p|$last|$pct")
      } finally {
        if ($softBmp) { try { $softBmp.Dispose() } catch {} }
        if ($memStream) { try { $memStream.Dispose() } catch {} }
        if ($page) { try { $page.Dispose() } catch {} }
      }

      if (($pagesDone % 25) -eq 0) {
        [GC]::Collect()
      }
    }
  } finally {
    $writer.Dispose()
  }

  $sw.Stop()
  $totalSec = [Math]::Round($sw.Elapsed.TotalSeconds, 1)
  if ($cancelled) {
    $cMsg = Say ("Прекъснато от потребителя. Запазени са $pagesDone страници в: $OutPath") ("Cancelled by user. Saved $pagesDone pages to: $OutPath")
    Write-Status 'cancelled' $pagesDone $spanCount ([Math]::Round(($pagesDone * 100.0) / $spanCount, 2)) $cMsg $OutPath $pagesDone
  } else {
    $okMsg = Say ("Готово! Разпознати $pagesDone стр. за ${totalSec} сек. Запазено в: $([IO.Path]::GetFileName($OutPath))") ("Done! Processed $pagesDone pages in ${totalSec}s. Saved to: $([IO.Path]::GetFileName($OutPath))")
    Write-Status 'done' $last $last 100.0 $okMsg $OutPath $pagesDone
  }
} catch {
  $err = $_.Exception.Message
  Write-Host ('ERROR: ' + $err)
  Write-Status 'error' $pagesDone 1 0 $err $OutPath $pagesDone
  exit 1
}
