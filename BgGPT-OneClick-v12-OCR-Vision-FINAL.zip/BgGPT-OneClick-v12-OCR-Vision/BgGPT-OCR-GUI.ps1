﻿# BgGPT Local OCR Reader + Scanned PDF Book OCR - 100% offline Windows 10/11 WinRT OCR & PDF.
# Zero Python, 0 MB extra models. Supports PNG/JPG/BMP/TIFF, Clipboard (Win+Shift+S), and full scanned PDF books with page range & progress bar.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Runtime.WindowsRuntime
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:ConfigPath = Join-Path $script:Root 'config.json'
$script:PdfWorkerScript = Join-Path $script:Root 'Convert-ScannedPdfToMarkdown.ps1'
$script:ModelAlias = 'BgGPT-Gemma-3-4B-IT-Q6_K.gguf'
if(Test-Path -LiteralPath $script:ConfigPath){
  try{
    $cfg = Get-Content -LiteralPath $script:ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if($cfg.modelAlias){ $script:ModelAlias = [string]$cfg.modelAlias }
  }catch{}
}
$script:ApiUrl = 'http://127.0.0.1:8080/v1/chat/completions'
$script:Lang = 'bg'
$script:OcrReady = $false
$script:PdfReady = $false
$script:AvailableLangs = @()
$script:BusyAi = $false
$script:PdfRunning = $false
$script:PdfWorker = $null
$script:PdfPath = ''
$script:PdfTotalPages = 0
$script:PdfOutPath = ''
$script:PdfStatusFile = ''
$script:PdfCancelFile = ''

# Initialize WinRT OCR & PDF types in Windows PowerShell 5.1
try{
  $null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
  $null = [Windows.Storage.FileAccessMode, Windows.Storage, ContentType = WindowsRuntime]
  $null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime]
  $null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
  $null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
  $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
  $null = [Windows.Media.Ocr.OcrResult, Windows.Foundation, ContentType = WindowsRuntime]
  $null = [Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime]

  $script:AsTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
  })[0]

  $script:AvailableLangs = @([Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages)
  $script:OcrReady = ($script:AvailableLangs.Count -gt 0)

  try{
    $null = [Windows.Data.Pdf.PdfDocument, Windows.Data.Pdf, ContentType = WindowsRuntime]
    $script:PdfReady = $true
  }catch{}
}catch{
  $script:OcrInitError = $_.Exception.Message
}

function Await-WinRT($WinRtTask, [Type]$ResultType) {
  $asTask = $script:AsTaskGeneric.MakeGenericMethod($ResultType)
  $netTask = $asTask.Invoke($null, @($WinRtTask))
  return $netTask.GetAwaiter().GetResult()
}

function Run-WindowsOcrFromBitmap([Drawing.Bitmap]$sourceBitmap, [string]$langTag) {
  if(-not $script:OcrReady){
    $errMsg = if($script:Lang -eq 'bg'){'Windows OCR не е достъпен или липсват езикови пакети за OCR.'}else{'Windows OCR is unavailable or no OCR language packs are installed.'}
    throw $errMsg
  }
  $maxDim = [int][Windows.Media.Ocr.OcrEngine]::MaxImageDimension
  if($maxDim -le 0){ $maxDim = 2500 }
  $targetW = $sourceBitmap.Width
  $targetH = $sourceBitmap.Height
  $resized = $null
  $workBmp = $sourceBitmap
  if($targetW -gt $maxDim -or $targetH -gt $maxDim){
    $scale = [Math]::Min(($maxDim * 1.0) / $targetW, ($maxDim * 1.0) / $targetH)
    $newW = [Math]::Max(1, [int][Math]::Floor($targetW * $scale))
    $newH = [Math]::Max(1, [int][Math]::Floor($targetH * $scale))
    $resized = New-Object Drawing.Bitmap $newW, $newH
    $g = [Drawing.Graphics]::FromImage($resized)
    try{
      $g.InterpolationMode = [Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
      $g.DrawImage($sourceBitmap, 0, 0, $newW, $newH)
    }finally{ $g.Dispose() }
    $workBmp = $resized
  }

  $tmpPng = Join-Path $env:TEMP ('bggpt-ocr-' + [guid]::NewGuid().ToString('N') + '.png')
  $stream = $null
  $softBmp = $null
  try{
    $workBmp.Save($tmpPng, [Drawing.Imaging.ImageFormat]::Png)
    $engine = $null
    if($langTag){
      $langObj = [Windows.Globalization.Language]::new($langTag)
      $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($langObj)
    }
    if($null -eq $engine){
      $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
    }
    if($null -eq $engine){
      throw ('Could not initialize Windows OCR for language: ' + $langTag)
    }
    $storageFile = Await-WinRT ([Windows.Storage.StorageFile]::GetFileFromPathAsync($tmpPng)) ([Windows.Storage.StorageFile])
    $stream = Await-WinRT ($storageFile.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
    $decoder = Await-WinRT ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $softBmp = Await-WinRT ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    $ocrRes = Await-WinRT ($engine.RecognizeAsync($softBmp)) ([Windows.Media.Ocr.OcrResult])
    $lines = @($ocrRes.Lines | ForEach-Object { [string]$_.Text })
    return ($lines -join "`r`n")
  }finally{
    if($softBmp){ try{ $softBmp.Dispose() }catch{} }
    if($stream){ try{ $stream.Dispose() }catch{} }
    if($resized){ try{ $resized.Dispose() }catch{} }
    if(Test-Path -LiteralPath $tmpPng){ Remove-Item -LiteralPath $tmpPng -Force -ErrorAction SilentlyContinue }
  }
}

$Ui = @{
 bg = @{
  win='BgGPT Local — Офлайн OCR четец за снимки и сканирани PDF книги';
  header='BgGPT · ЛОКАЛЕН OCR ЧЕТЕЦ ЗА СНИМКИ И PDF КНИГИ (100% ОФЛАЙН)';
  sub='Провлачете PNG/JPG снимка или сканиран PDF файл тук, отворете файл или поставете екранна снимка (Win+Shift+S -> Ctrl+V).';
  open='ОТВОРИ СНИМКА'; openPdf='ОТВОРИ PDF'; paste='ОТ КЛИПБОРДА (Ctrl+V)'; lang='Език OCR:';
  pdfHint='PDF книга: провлачете .PDF тук или натиснете «Отвори PDF» (записва .ocr.md за AnythingLLM)';
  fromPg='От стр.'; toPg='До стр.'; startPdf='СТАРТ PDF OCR'; stopPdf='СПРИ PDF OCR'; openFolder='ОТВОРИ ПАПКА';
  pdfIdle='0,00% · Няма стартиран PDF OCR';
  ocrLbl='ИЗВЛЕЧЕН ТЕКСТ (редактируем · при PDF показва преглед на началото)';
  copy='КОПИРАЙ ТЕКСТА'; save='ЗАПАЗИ .TXT/.MD'; clear='ИЗЧИСТИ';
  promptLbl='ВЪПРОС / ЗАДАЧА КЪМ ЛОКАЛНИЯ BgGPT';
  ask='ИЗПРАТИ КЪМ BgGPT';
  ansLbl='ОТГОВОР ОТ BgGPT (127.0.0.1:8080)';
  copyAns='КОПИРАЙ ОТГОВОРА'; startSrv='СТАРТИРАЙ BgGPT';
  presets=@(
    'Обясни накратко и ясно текста и данните от този документ/снимка.',
    'Подреди данните в чиста и прегледна таблица.',
    'Поправи евентуални OCR грешки и форматирай текста четимо.',
    'Преведи текста на български и извади ключовите научни изводи.'
  );
  ready='Готов. Провлачете изображение или PDF книга, или използвайте бутоните отгоре.';
  noBgWarn='Забележка: В Windows липсва BG OCR пакет. Добавете «Български» в Settings → Time & Language → Language или изпълнете като Admin: Add-WindowsCapability -Online -Name Language.OCR~~~bg-BG~0.0.1.0';
  workingOcr='Разпознаване на текста чрез Windows OCR...';
  workingAi='Изпращане към локалния BgGPT (127.0.0.1:8080)...';
  noImgClip='В клипборда няма изображение. Направете екранна снимка (Win+Shift+S) и опитайте отново.';
  noText='Няма извлечен текст за изпращане към BgGPT.';
  copied='Текстът е копиран в клипборда (готов за поставяне в AnythingLLM или Word).';
  saved='Текстът е запазен във файл: ';
  srvHint='BgGPT сървърът не отговаря на 127.0.0.1:8080. Натиснете «Стартирай BgGPT» и опитайте отново.'
 };
 en = @{
  win='BgGPT Local — Offline OCR Reader for Images & Scanned PDF Books';
  header='BgGPT · LOCAL IMAGE & PDF BOOK OCR READER (100% OFFLINE)';
  sub='Drag & drop a PNG/JPG image or scanned PDF file here, open a file, or paste a screenshot (Win+Shift+S -> Ctrl+V).';
  open='OPEN IMAGE'; openPdf='OPEN PDF'; paste='FROM CLIPBOARD (Ctrl+V)'; lang='OCR Lang:';
  pdfHint='PDF Book: drag & drop a .PDF here or click "Open PDF" (saves .ocr.md ready for AnythingLLM)';
  fromPg='From pg.'; toPg='To pg.'; startPdf='START PDF OCR'; stopPdf='STOP PDF OCR'; openFolder='OPEN FOLDER';
  pdfIdle='0.00% · Ready for PDF';
  ocrLbl='EXTRACTED TEXT (editable · shows preview for large PDF books)';
  copy='COPY TEXT'; save='SAVE .TXT/.MD'; clear='CLEAR';
  promptLbl='QUESTION / TASK FOR LOCAL BgGPT';
  ask='ASK LOCAL BgGPT';
  ansLbl='BgGPT RESPONSE (127.0.0.1:8080)';
  copyAns='COPY ANSWER'; startSrv='START BgGPT';
  presets=@(
    'Explain and summarize the text and data clearly.',
    'Organize the extracted data into a clean Markdown table.',
    'Fix any OCR typos and format the text cleanly.',
    'Translate the text into Bulgarian and list key research takeaways.'
  );
  ready='Ready. Drag & drop an image or PDF book, or use the toolbar buttons.';
  noBgWarn='Note: Bulgarian OCR pack is missing in Windows. Add Bulgarian in Settings -> Time & Language -> Language or run as Admin: Add-WindowsCapability -Online -Name Language.OCR~~~bg-BG~0.0.1.0';
  workingOcr='Extracting text with Windows OCR...';
  workingAi='Sending text to local BgGPT (127.0.0.1:8080)...';
  noImgClip='Clipboard does not contain an image. Take a screenshot (Win+Shift+S) and try again.';
  noText='No extracted text available to send to BgGPT.';
  copied='Copied to clipboard (ready to paste into AnythingLLM or Word).';
  saved='Saved text to: ';
  srvHint='Local BgGPT server is not running on 127.0.0.1:8080. Click "Start BgGPT" and retry.'
 }
}
function T([string]$k){ return [string]$Ui[$script:Lang][$k] }

$C = @{
  bg=[Drawing.Color]::FromArgb(11,18,29);
  panel=[Drawing.Color]::FromArgb(18,28,42);
  box=[Drawing.Color]::FromArgb(24,36,52);
  main=[Drawing.Color]::FromArgb(244,249,250);
  dim=[Drawing.Color]::FromArgb(157,177,193);
  green=[Drawing.Color]::FromArgb(66,221,148);
  aqua=[Drawing.Color]::FromArgb(43,194,183);
  warn=[Drawing.Color]::FromArgb(245,196,81);
  danger=[Drawing.Color]::FromArgb(186,62,62)
}
function F([float]$sz,[bool]$bold=$false,[string]$fam='Segoe UI'){
  $st = if($bold){[Drawing.FontStyle]::Bold}else{[Drawing.FontStyle]::Regular}
  return [Drawing.Font]::new($fam,$sz,$st)
}

$form = New-Object Windows.Forms.Form
$form.Text = T 'win'
$form.StartPosition = 'CenterScreen'
$form.Size = [Drawing.Size]::new(1060, 820)
$form.MinimumSize = [Drawing.Size]::new(1060, 820)
$form.MaximumSize = [Drawing.Size]::new(1060, 820)
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false
$form.BackColor = $C.bg
$form.ForeColor = $C.main
$form.Font = F 10
$form.AllowDrop = $true
$form.KeyPreview = $true

function Make-Label($parent,$x,$y,$w,$h,$txt,$sz=10,$bold=$false,$fg=$C.main){
  $l = New-Object Windows.Forms.Label
  $l.SetBounds($x,$y,$w,$h)
  $l.Text = $txt; $l.ForeColor = $fg; $l.Font = F $sz $bold
  $l.BackColor = [Drawing.Color]::Transparent
  $parent.Controls.Add($l); return $l
}
function Make-Btn($parent,$x,$y,$w,$h,$txt,$bgc=$C.box){
  $b = New-Object Windows.Forms.Button
  $b.SetBounds($x,$y,$w,$h)
  $b.Text = $txt; $b.BackColor = $bgc; $b.ForeColor = $C.main; $b.FlatStyle = 'Flat'
  $b.FlatAppearance.BorderSize = 0; $b.Font = F 9 $true; $b.Cursor = [Windows.Forms.Cursors]::Hand
  $parent.Controls.Add($b); return $b
}

# Header
$lblHead = Make-Label $form 20 12 830 28 (T 'header') 13 $true $C.green
$btnEn = Make-Btn $form 880 10 68 28 'EN' $C.box
$btnBg = Make-Btn $form 956 10 68 28 'BG' $C.aqua
$lblSub = Make-Label $form 20 42 1005 22 (T 'sub') 9 $false $C.dim

# Main Toolbar
$btnOpen = Make-Btn $form 20 70 148 34 (T 'open') $C.aqua
$btnOpenPdf = Make-Btn $form 176 70 132 34 (T 'openPdf') $C.aqua
$btnPaste = Make-Btn $form 316 70 192 34 (T 'paste') $C.box
$lblOcrLang = Make-Label $form 518 77 74 22 (T 'lang') 9 $true $C.dim
$cmbLang = New-Object Windows.Forms.ComboBox
$cmbLang.SetBounds(594,73,258,28)
$cmbLang.DropDownStyle = 'DropDownList'
$cmbLang.BackColor = $C.box; $cmbLang.ForeColor = $C.main; $cmbLang.Font = F 9
$form.Controls.Add($cmbLang)
$btnStartSrv = Make-Btn $form 864 70 160 34 (T 'startSrv') $C.box

# Populate Windows OCR Languages (prioritize bg-BG)
$script:LangTags = @()
$bgIndex = -1
foreach($l in $script:AvailableLangs){
  $tag = [string]$l.LanguageTag
  $disp = [string]$l.DisplayName
  $idx = $cmbLang.Items.Add("$tag — $disp")
  $script:LangTags += $tag
  if($tag -like 'bg*' -and $bgIndex -lt 0){ $bgIndex = $idx }
}
if($cmbLang.Items.Count -gt 0){
  $cmbLang.SelectedIndex = if($bgIndex -ge 0){ $bgIndex } else { 0 }
}

# ==============================================================================
# Native Windows PDF Book OCR Panel (Page Range + Progress Bar + Stop + Folder)
# ==============================================================================
$pdfPanel = New-Object Windows.Forms.Panel
$pdfPanel.SetBounds(20,114,1004,76)
$pdfPanel.BackColor = $C.panel
$pdfPanel.BorderStyle = 'FixedSingle'
$pdfPanel.AllowDrop = $true
$form.Controls.Add($pdfPanel)

$lblPdfFile = Make-Label $pdfPanel 10 9 452 22 (T 'pdfHint') 9 $true $C.main
$lblFrom = Make-Label $pdfPanel 468 10 52 20 (T 'fromPg') 9 $false $C.dim
$numStart = New-Object Windows.Forms.NumericUpDown
$numStart.SetBounds(522,7,62,24)
$numStart.Minimum = 1; $numStart.Maximum = 99999; $numStart.Value = 1
$numStart.BackColor = $C.box; $numStart.ForeColor = $C.main; $numStart.Font = F 9
$pdfPanel.Controls.Add($numStart)

$lblTo = Make-Label $pdfPanel 592 10 50 20 (T 'toPg') 9 $false $C.dim
$numEnd = New-Object Windows.Forms.NumericUpDown
$numEnd.SetBounds(644,7,62,24)
$numEnd.Minimum = 1; $numEnd.Maximum = 99999; $numEnd.Value = 1
$numEnd.BackColor = $C.box; $numEnd.ForeColor = $C.main; $numEnd.Font = F 9
$pdfPanel.Controls.Add($numEnd)

$btnPdfRun = Make-Btn $pdfPanel 716 5 148 28 (T 'startPdf') $C.aqua
$btnPdfRun.Enabled = $false
$btnPdfFolder = Make-Btn $pdfPanel 872 5 122 28 (T 'openFolder') $C.box
$btnPdfFolder.Enabled = $false

$barPdf = New-Object Windows.Forms.ProgressBar
$barPdf.SetBounds(10,43,696,20)
$barPdf.Style = 'Continuous'; $barPdf.Minimum = 0; $barPdf.Maximum = 100; $barPdf.Value = 0
$pdfPanel.Controls.Add($barPdf)

$lblPdfPct = Make-Label $pdfPanel 716 44 278 20 (T 'pdfIdle') 9 $true $C.green

# ==============================================================================
# Extracted OCR Text Area
# ==============================================================================
$lblOcr = Make-Label $form 20 200 560 22 (T 'ocrLbl') 9 $true $C.green
$btnCopyOcr = Make-Btn $form 610 196 142 26 (T 'copy') $C.box
$btnSaveOcr = Make-Btn $form 760 196 138 26 (T 'save') $C.box
$btnClear = Make-Btn $form 906 196 118 26 (T 'clear') $C.box

$txtOcr = New-Object Windows.Forms.TextBox
$txtOcr.SetBounds(20,226,1004,190)
$txtOcr.Multiline = $true; $txtOcr.ScrollBars = 'Vertical'
$txtOcr.BackColor = $C.panel; $txtOcr.ForeColor = $C.main
$txtOcr.BorderStyle = 'FixedSingle'; $txtOcr.Font = F 10 $false 'Consolas'
$txtOcr.AllowDrop = $true
$form.Controls.Add($txtOcr)

# Prompt controls + presets
$lblPrompt = Make-Label $form 20 426 450 22 (T 'promptLbl') 9 $true $C.green
$cmbPreset = New-Object Windows.Forms.ComboBox
$cmbPreset.SetBounds(20,450,798,28)
$cmbPreset.DropDownStyle = 'DropDown'
$cmbPreset.BackColor = $C.box; $cmbPreset.ForeColor = $C.main; $cmbPreset.Font = F 10
foreach($p in $Ui[$script:Lang]['presets']){ [void]$cmbPreset.Items.Add($p) }
$cmbPreset.SelectedIndex = 0
$form.Controls.Add($cmbPreset)
$btnAsk = Make-Btn $form 828 448 196 31 (T 'ask') $C.aqua

# BgGPT Answer box
$lblAns = Make-Label $form 20 492 450 22 (T 'ansLbl') 9 $true $C.green
$btnCopyAns = Make-Btn $form 864 488 160 26 (T 'copyAns') $C.box

$txtAns = New-Object Windows.Forms.TextBox
$txtAns.SetBounds(20,518,1004,205)
$txtAns.Multiline = $true; $txtAns.ScrollBars = 'Vertical'; $txtAns.ReadOnly = $true
$txtAns.BackColor = $C.panel; $txtAns.ForeColor = $C.main
$txtAns.BorderStyle = 'FixedSingle'; $txtAns.Font = F 10
$form.Controls.Add($txtAns)

# Status bar
$lblStatus = Make-Label $form 20 732 1004 38 (T 'ready') 9 $false $C.dim
if($bgIndex -lt 0){
  $lblStatus.Text = T 'noBgWarn'
  $lblStatus.ForeColor = $C.warn
}

function Set-Status([string]$msg,$color=$C.dim){
  $lblStatus.Text = $msg
  $lblStatus.ForeColor = $color
  $form.Refresh()
}

function Format-Pct([double]$val){
  $culture = if($script:Lang -eq 'bg'){[Globalization.CultureInfo]::GetCultureInfo('bg-BG')}else{[Globalization.CultureInfo]::GetCultureInfo('en-US')}
  return $val.ToString('N2',$culture) + '%'
}

function Get-SelectedOcrTag {
  if($cmbLang.SelectedIndex -ge 0 -and $cmbLang.SelectedIndex -lt $script:LangTags.Count){
    return [string]$script:LangTags[$cmbLang.SelectedIndex]
  }
  return ''
}

function Load-PdfFile([string]$path){
  if($script:PdfRunning){
    $warnBusy = if($script:Lang -eq 'bg'){'В момента тече PDF OCR. Първо натиснете «Спри PDF OCR».'}else{'A PDF OCR job is currently running. Click Stop first.'}
    Set-Status $warnBusy $C.warn
    return
  }
  if(-not $script:PdfReady){
    $noPdf = if($script:Lang -eq 'bg'){'Windows.Data.Pdf не е достъпен на тази система.'}else{'Windows.Data.Pdf is unavailable on this system.'}
    Set-Status $noPdf ([Drawing.Color]::Salmon)
    return
  }
  try{
    $full = (Resolve-Path -LiteralPath $path).Path
    $sf = Await-WinRT ([Windows.Storage.StorageFile]::GetFileFromPathAsync($full)) ([Windows.Storage.StorageFile])
    $doc = Await-WinRT ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($sf)) ([Windows.Data.Pdf.PdfDocument])
    $cnt = [int]$doc.PageCount
    if($cnt -le 0){ throw 'PDF has 0 pages.' }

    $script:PdfPath = $full
    $script:PdfTotalPages = $cnt
    $script:PdfOutPath = [IO.Path]::ChangeExtension($full, '.ocr.md')

    $numStart.Maximum = $cnt
    $numEnd.Maximum = $cnt
    $numStart.Value = 1
    $numEnd.Value = $cnt
    $barPdf.Value = 0
    $btnPdfRun.Enabled = $true
    $btnPdfFolder.Enabled = (Test-Path -LiteralPath $script:PdfOutPath)

    $fname = [IO.Path]::GetFileName($full)
    $pgWord = if($script:Lang -eq 'bg'){'стр.'}else{'pages'}
    $lblPdfFile.Text = "PDF: $fname ($cnt $pgWord)"
    $lblPdfFile.ForeColor = $C.green
    $readyTag = if($script:Lang -eq 'bg'){"Готов ($cnt стр.)"}else{"Ready ($cnt pages)"}
    $lblPdfPct.Text = (Format-Pct 0.0) + ' · ' + $readyTag

    $readyMsg = if($script:Lang -eq 'bg'){"Зареден PDF: $fname ($cnt стр.). Изберете диапазон и натиснете «СТАРТ PDF OCR»."}else{"Loaded PDF: $fname ($cnt pages). Choose page range and click START PDF OCR."}
    Set-Status $readyMsg $C.green
  }catch{
    Set-Status ('PDF ERROR: ' + $_.Exception.Message) ([Drawing.Color]::Salmon)
  }
}

function Process-ImageFile([string]$path){
  if(-not(Test-Path -LiteralPath $path -PathType Leaf)){ return }
  if([IO.Path]::GetExtension($path) -ieq '.pdf'){
    Load-PdfFile $path
    return
  }
  Set-Status (T 'workingOcr') $C.aqua
  $sw = [Diagnostics.Stopwatch]::StartNew()
  $bmp = $null
  try{
    $bytes = [IO.File]::ReadAllBytes($path)
    $ms = New-Object IO.MemoryStream(,$bytes)
    try{
      $rawBmp = [Drawing.Bitmap]::new($ms)
      try{
        $bmp = New-Object Drawing.Bitmap($rawBmp.Width, $rawBmp.Height, [Drawing.Imaging.PixelFormat]::Format32bppArgb)
        $gLoad = [Drawing.Graphics]::FromImage($bmp)
        try{ $gLoad.DrawImage($rawBmp, 0, 0, $rawBmp.Width, $rawBmp.Height) }finally{ $gLoad.Dispose() }
      }finally{ $rawBmp.Dispose() }
    }finally{ $ms.Dispose() }
    $tag = Get-SelectedOcrTag
    $text = Run-WindowsOcrFromBitmap $bmp $tag
    $sw.Stop()
    $txtOcr.Text = $text
    $sec = [Math]::Round($sw.Elapsed.TotalSeconds, 2)
    $chars = $text.Length
    $okMsg = if($script:Lang -eq 'bg'){"[OK] OCR завърши за $sec сек. ($chars символа, език: $tag) — $([IO.Path]::GetFileName($path))"}else{"[OK] OCR completed in ${sec}s ($chars chars, lang: $tag) — $([IO.Path]::GetFileName($path))"}
    Set-Status $okMsg $C.green
  }catch{
    Set-Status ('ERROR: ' + $_.Exception.Message) ([Drawing.Color]::Salmon)
  }finally{
    if($bmp){ $bmp.Dispose() }
  }
}

function Process-ClipboardImage {
  if(-not [Windows.Forms.Clipboard]::ContainsImage()){
    Set-Status (T 'noImgClip') $C.warn
    return
  }
  Set-Status (T 'workingOcr') $C.aqua
  $sw = [Diagnostics.Stopwatch]::StartNew()
  $img = $null; $bmp = $null
  try{
    $img = [Windows.Forms.Clipboard]::GetImage()
    $bmp = New-Object Drawing.Bitmap($img.Width, $img.Height, [Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $gClip = [Drawing.Graphics]::FromImage($bmp)
    try{ $gClip.DrawImage($img, 0, 0, $img.Width, $img.Height) }finally{ $gClip.Dispose() }
    $tag = Get-SelectedOcrTag
    $text = Run-WindowsOcrFromBitmap $bmp $tag
    $sw.Stop()
    $txtOcr.Text = $text
    $sec = [Math]::Round($sw.Elapsed.TotalSeconds, 2)
    $chars = $text.Length
    $okMsg = if($script:Lang -eq 'bg'){"[OK] OCR от клипборда за $sec сек. ($chars символа, език: $tag)"}else{"[OK] Clipboard OCR completed in ${sec}s ($chars chars, lang: $tag)"}
    Set-Status $okMsg $C.green
  }catch{
    Set-Status ('ERROR: ' + $_.Exception.Message) ([Drawing.Color]::Salmon)
  }finally{
    if($bmp){ $bmp.Dispose() }
    if($img){ $img.Dispose() }
  }
}

function Load-PdfOutputPreview([string]$mdPath){
  if(-not (Test-Path -LiteralPath $mdPath -PathType Leaf)){ return }
  try{
    $fullText = [IO.File]::ReadAllText($mdPath, [Text.Encoding]::UTF8)
    if($fullText.Length -gt 14000){
      $previewNote = if($script:Lang -eq 'bg'){"`r`n`r`n--- [Показани са първите 14 000 знака. Пълната книга е запазена в: $mdPath] ---"}else{"`r`n`r`n--- [Showing first 14,000 chars. Full book saved to: $mdPath] ---"}
      $txtOcr.Text = $fullText.Substring(0, 14000).Replace("`r`n","`n").Replace("`n","`r`n") + $previewNote
    }else{
      $txtOcr.Text = $fullText.Replace("`r`n","`n").Replace("`n","`r`n")
    }
  }catch{}
}

function Render-Lang {
  $form.Text = T 'win'; $lblHead.Text = T 'header'; $lblSub.Text = T 'sub'
  $btnOpen.Text = T 'open'; $btnOpenPdf.Text = T 'openPdf'; $btnPaste.Text = T 'paste'; $lblOcrLang.Text = T 'lang'
  $lblFrom.Text = T 'fromPg'; $lblTo.Text = T 'toPg'; $btnPdfFolder.Text = T 'openFolder'
  $btnPdfRun.Text = if($script:PdfRunning){ T 'stopPdf' }else{ T 'startPdf' }
  if(-not $script:PdfPath){ $lblPdfFile.Text = T 'pdfHint'; $lblPdfPct.Text = T 'pdfIdle' }
  $lblOcr.Text = T 'ocrLbl'; $btnCopyOcr.Text = T 'copy'; $btnSaveOcr.Text = T 'save'; $btnClear.Text = T 'clear'
  $lblPrompt.Text = T 'promptLbl'; $btnAsk.Text = T 'ask'; $lblAns.Text = T 'ansLbl'
  $btnCopyAns.Text = T 'copyAns'; $btnStartSrv.Text = T 'startSrv'
  $btnBg.BackColor = if($script:Lang -eq 'bg'){$C.aqua}else{$C.box}
  $btnEn.BackColor = if($script:Lang -eq 'en'){$C.aqua}else{$C.box}
  $cmbPreset.Items.Clear()
  foreach($p in $Ui[$script:Lang]['presets']){ [void]$cmbPreset.Items.Add($p) }
  $cmbPreset.SelectedIndex = 0
}

$btnBg.Add_Click({ $script:Lang = 'bg'; Render-Lang })
$btnEn.Add_Click({ $script:Lang = 'en'; Render-Lang })

$btnOpen.Add_Click({
  $dlg = New-Object Windows.Forms.OpenFileDialog
  $dlg.Filter = 'Images & PDF (*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.webp;*.pdf)|*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.webp;*.pdf|All files (*.*)|*.*'
  if($dlg.ShowDialog() -eq [Windows.Forms.DialogResult]::OK){
    Process-ImageFile $dlg.FileName
  }
})

$btnOpenPdf.Add_Click({
  $dlg = New-Object Windows.Forms.OpenFileDialog
  $dlg.Filter = 'PDF Documents (*.pdf)|*.pdf|All files (*.*)|*.*'
  if($dlg.ShowDialog() -eq [Windows.Forms.DialogResult]::OK){
    Load-PdfFile $dlg.FileName
  }
})

$btnPaste.Add_Click({ Process-ClipboardImage })

$btnPdfFolder.Add_Click({
  if($script:PdfOutPath -and (Test-Path -LiteralPath $script:PdfOutPath)){
    Start-Process -FilePath 'explorer.exe' -ArgumentList ('/select,"' + $script:PdfOutPath + '"')
  }elseif($script:PdfPath){
    Start-Process -FilePath 'explorer.exe' -ArgumentList ('"' + (Split-Path -Parent $script:PdfPath) + '"')
  }
})

# Start or Stop isolated PDF OCR worker process
$btnPdfRun.Add_Click({
  if($script:PdfRunning){
    if($script:PdfCancelFile){
      try{ New-Item -Path $script:PdfCancelFile -ItemType File -Force | Out-Null }catch{}
    }
    $stoppingMsg = if($script:Lang -eq 'bg'){'Спиране след текущата страница (обработените страници се запазват)...'}else{'Stopping after current page (completed pages are preserved)...'}
    Set-Status $stoppingMsg $C.warn
    return
  }
  if(-not $script:PdfPath -or -not (Test-Path -LiteralPath $script:PdfPath)){ return }
  if(-not (Test-Path -LiteralPath $script:PdfWorkerScript)){
    Set-Status 'Missing Convert-ScannedPdfToMarkdown.ps1 in BgGPT-Local folder.' ([Drawing.Color]::Salmon)
    return
  }

  $sPg = [int]$numStart.Value
  $ePg = [int]$numEnd.Value
  if($ePg -lt $sPg){ $ePg = $sPg; $numEnd.Value = $ePg }

  $runId = [guid]::NewGuid().ToString('N')
  $script:PdfStatusFile = Join-Path $env:TEMP ('bggpt-pdf-status-' + $runId + '.json')
  $script:PdfCancelFile = Join-Path $env:TEMP ('bggpt-pdf-cancel-' + $runId + '.flag')
  $tag = Get-SelectedOcrTag
  if(-not $tag){ $tag = 'bg-BG' }

  $argStr = '-NoProfile -ExecutionPolicy Bypass -File "' + $script:PdfWorkerScript + '"' +
            ' -PdfPath "' + $script:PdfPath + '"' +
            ' -OutPath "' + $script:PdfOutPath + '"' +
            ' -LanguageTag "' + $tag + '"' +
            ' -StartPage ' + $sPg +
            ' -EndPage ' + $ePg +
            ' -StatusFile "' + $script:PdfStatusFile + '"' +
            ' -CancelFile "' + $script:PdfCancelFile + '"' +
            ' -UiLang ' + $script:Lang

  try{
    $script:PdfWorker = Start-Process -FilePath 'powershell.exe' -ArgumentList $argStr -WorkingDirectory $script:Root -PassThru -WindowStyle Hidden
    $script:PdfRunning = $true
    $barPdf.Value = 0
    $numStart.Enabled = $false; $numEnd.Enabled = $false; $btnOpenPdf.Enabled = $false; $cmbLang.Enabled = $false
    $btnPdfRun.Text = T 'stopPdf'
    $btnPdfRun.BackColor = $C.danger
    $startMsg = if($script:Lang -eq 'bg'){"Стартиран PDF OCR (стр. $sPg–$ePg, език: $tag)..."}else{"Started PDF OCR (pages $sPg-$ePg, lang: $tag)..."}
    Set-Status $startMsg $C.aqua
  }catch{
    Set-Status ('ERROR: ' + $_.Exception.Message) ([Drawing.Color]::Salmon)
  }
})

# Poll PDF OCR worker progress without blocking WinForms UI
$pdfTimer = New-Object Windows.Forms.Timer
$pdfTimer.Interval = 350
$pdfTimer.Add_Tick({
  if(-not $script:PdfRunning){ return }
  try{
    if($script:PdfStatusFile -and (Test-Path -LiteralPath $script:PdfStatusFile)){
      $st = Get-Content -LiteralPath $script:PdfStatusFile -Raw -Encoding UTF8 | ConvertFrom-Json
      $p = [Math]::Max(0.0, [Math]::Min(100.0, [double]$st.percent))
      $barPdf.Value = [int][Math]::Round($p)
      $pgLabel = if($script:Lang -eq 'bg'){'Стр.'}else{'Pg.'}
      $lblPdfPct.Text = (Format-Pct $p) + " · $pgLabel $($st.current) / $($st.total)"
      if($st.note){ Set-Status ([string]$st.note) $C.aqua }

      if($st.kind -eq 'done' -or $st.kind -eq 'cancelled' -or $st.kind -eq 'error'){
        $script:PdfRunning = $false
        $numStart.Enabled = $true; $numEnd.Enabled = $true; $btnOpenPdf.Enabled = $true; $cmbLang.Enabled = $true
        $btnPdfRun.Text = T 'startPdf'
        $btnPdfRun.BackColor = $C.aqua
        if($st.kind -eq 'done'){
          $btnPdfFolder.Enabled = $true
          Set-Status ([string]$st.note) $C.green
          Load-PdfOutputPreview ([string]$st.outPath)
        }elseif($st.kind -eq 'cancelled'){
          $btnPdfFolder.Enabled = (Test-Path -LiteralPath ([string]$st.outPath))
          Set-Status ([string]$st.note) $C.warn
          Load-PdfOutputPreview ([string]$st.outPath)
        }else{
          Set-Status ('PDF OCR ERROR: ' + [string]$st.note) ([Drawing.Color]::Salmon)
        }
        try{ Remove-Item -LiteralPath $script:PdfStatusFile -Force -ErrorAction SilentlyContinue }catch{}
        try{ Remove-Item -LiteralPath $script:PdfCancelFile -Force -ErrorAction SilentlyContinue }catch{}
        return
      }
    }
    if($script:PdfWorker){
      $script:PdfWorker.Refresh()
      if($script:PdfWorker.HasExited -and $script:PdfRunning){
        $script:PdfRunning = $false
        $numStart.Enabled = $true; $numEnd.Enabled = $true; $btnOpenPdf.Enabled = $true; $cmbLang.Enabled = $true
        $btnPdfRun.Text = T 'startPdf'
        $btnPdfRun.BackColor = $C.aqua
        $exMsg = if($script:Lang -eq 'bg'){'PDF OCR процесът приключи неочаквано.'}else{'PDF OCR worker exited unexpectedly.'}
        Set-Status $exMsg ([Drawing.Color]::Salmon)
      }
    }
  }catch{}
})
$pdfTimer.Start()

$btnCopyOcr.Add_Click({
  if(-not [string]::IsNullOrEmpty($txtOcr.Text)){
    [Windows.Forms.Clipboard]::SetText($txtOcr.Text)
    Set-Status (T 'copied') $C.green
  }
})

$btnCopyAns.Add_Click({
  if(-not [string]::IsNullOrEmpty($txtAns.Text)){
    [Windows.Forms.Clipboard]::SetText($txtAns.Text)
    Set-Status (T 'copied') $C.green
  }
})

$btnSaveOcr.Add_Click({
  if([string]::IsNullOrWhiteSpace($txtOcr.Text)){ return }
  $dlg = New-Object Windows.Forms.SaveFileDialog
  $dlg.Filter = 'Markdown (*.md)|*.md|Text file (*.txt)|*.txt'
  $dlg.FileName = 'ocr-extracted.md'
  if($dlg.ShowDialog() -eq [Windows.Forms.DialogResult]::OK){
    [IO.File]::WriteAllText($dlg.FileName, $txtOcr.Text, [Text.Encoding]::UTF8)
    Set-Status ((T 'saved') + $dlg.FileName) $C.green
  }
})

$btnClear.Add_Click({
  $txtOcr.Clear(); $txtAns.Clear(); Set-Status (T 'ready') $C.dim
})

$btnStartSrv.Add_Click({
  $startCmd = Join-Path $script:Root 'START.cmd'
  if(Test-Path -LiteralPath $startCmd){
    Start-Process -FilePath $startCmd -WorkingDirectory $script:Root
    $srvMsg = if($script:Lang -eq 'bg'){'Стартиране на локалния BgGPT сървър...'}else{'Starting local BgGPT server...'}
    Set-Status $srvMsg $C.aqua
  }
})

# Drag & drop handler on Form, PDF panel, and OCR TextBox (handles Images AND PDFs!)
$dragEnter = {
  param($s,$e)
  if($e.Data.GetDataPresent([Windows.Forms.DataFormats]::FileDrop)){
    $e.Effect = [Windows.Forms.DragDropEffects]::Copy
  }
}
$dragDrop = {
  param($s,$e)
  $dropped = $e.Data.GetData([Windows.Forms.DataFormats]::FileDrop)
  if($dropped -and $dropped.Length -gt 0){ Process-ImageFile ([string]$dropped[0]) }
}
$form.Add_DragEnter($dragEnter); $form.Add_DragDrop($dragDrop)
$pdfPanel.Add_DragEnter($dragEnter); $pdfPanel.Add_DragDrop($dragDrop)
$txtOcr.Add_DragEnter($dragEnter); $txtOcr.Add_DragDrop($dragDrop)

# Ctrl+V shortcut when clipboard holds an image
$form.Add_KeyDown({
  param($s,$e)
  if($e.Control -and $e.KeyCode -eq [Windows.Forms.Keys]::V -and [Windows.Forms.Clipboard]::ContainsImage()){
    $e.SuppressKeyPress = $true
    Process-ClipboardImage
  }
})

# Non-blocking local API request to BgGPT
$btnAsk.Add_Click({
  if($script:BusyAi){ return }
  $ocrText = $txtOcr.Text.Trim()
  if([string]::IsNullOrWhiteSpace($ocrText)){
    Set-Status (T 'noText') $C.warn
    return
  }
  $task = $cmbPreset.Text.Trim()
  if([string]::IsNullOrWhiteSpace($task)){ $task = $Ui[$script:Lang]['presets'][0] }
  if($ocrText.Length -gt 9000){ $ocrText = $ocrText.Substring(0, 9000) + "`r`n...[съкратено]" }
  $combined = "$task`r`n`r`n--- OCR ТЕКСТ ---`r`n$ocrText"

  $payload = @{
    model = $script:ModelAlias;
    temperature = 0.2;
    max_tokens = 1024;
    messages = @(
      @{ role = 'system'; content = 'Ти си прецизен български научен и технически асистент BgGPT. Отговаряй ясно и точно въз основа на предоставения OCR текст.' },
      @{ role = 'user'; content = $combined }
    )
  } | ConvertTo-Json -Depth 6 -Compress

  $script:BusyAi = $true
  $btnAsk.Enabled = $false
  $txtAns.Text = ''
  Set-Status (T 'workingAi') $C.aqua

  $wc = New-Object System.Net.WebClient
  $wc.Encoding = [Text.Encoding]::UTF8
  $wc.Headers.Add('Content-Type', 'application/json; charset=utf-8')
  $wc.Add_UploadStringCompleted({
    param($sender, $ev)
    $script:BusyAi = $false
    $btnAsk.Enabled = $true
    try{
      if($ev.Error){
        $txtAns.Text = (T 'srvHint') + "`r`n`r`n" + $ev.Error.Message
        Set-Status (T 'srvHint') ([Drawing.Color]::Salmon)
      }else{
        $parsed = $ev.Result | ConvertFrom-Json
        $reply = [string]$parsed.choices[0].message.content
        $txtAns.Text = $reply.Replace("`r`n","`n").Replace("`n","`r`n")
        $okAiMsg = if($script:Lang -eq 'bg'){'[OK] Отговорът от локалния BgGPT е готов.'}else{'[OK] Local BgGPT response ready.'}
        Set-Status $okAiMsg $C.green
      }
    }catch{
      $txtAns.Text = $_.Exception.Message
      Set-Status ('ERROR: ' + $_.Exception.Message) ([Drawing.Color]::Salmon)
    }finally{
      try{ $sender.Dispose() }catch{}
    }
  })
  $wc.UploadStringAsync([Uri]$script:ApiUrl, 'POST', $payload)
})

$form.Add_FormClosing({
  if($script:PdfRunning -and $script:PdfCancelFile){
    try{ New-Item -Path $script:PdfCancelFile -ItemType File -Force | Out-Null }catch{}
  }
})

[void]$form.ShowDialog()
$pdfTimer.Stop(); $pdfTimer.Dispose()
