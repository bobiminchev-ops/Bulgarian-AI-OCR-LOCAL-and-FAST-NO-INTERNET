# BgGPT Local — OneClick Universal v12 Hybrid (OCR + PDF Books + SmolVLM2-2.2B Vision)

**All-in-one 100% local Windows installer (zero Python, zero Admin rights):**

- **Fast text chat:** BgGPT-Gemma-3-4B-IT runs at full speed on `127.0.0.1:8081` (4096 context) with zero Vision slowdown.
- **Hybrid Image Bridge (`127.0.0.1:8080`):** Text-heavy screenshots/documents use 1–2s offline Windows OCR; photos of objects, animals, scenes, charts, and maps automatically invoke **SmolVLM2-2.2B-Instruct** on demand via `llama-mtmd-cli.exe` (freeing RAM immediately after describing the image) so BgGPT answers naturally in Bulgarian or English inside AnythingLLM and the browser UI.
- **Scanned PDF Books (`BgGPT Local - OCR`):** Native `Windows.Data.Pdf` + `Windows.Media.Ocr` converts scanned PDFs to page-marked `.ocr.md` files for AnythingLLM RAG.
