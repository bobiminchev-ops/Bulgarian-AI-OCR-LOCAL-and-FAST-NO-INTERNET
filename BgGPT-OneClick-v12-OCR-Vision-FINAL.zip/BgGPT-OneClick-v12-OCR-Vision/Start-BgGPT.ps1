﻿# BgGPT Local v12 + Auto OCR Bridge:
# - Runs fast llama-server.exe internally on 127.0.0.1:8081 (no heavy mmproj, context 4096).
# - Runs transparent offline Windows OCR Bridge on 127.0.0.1:8080 so AnythingLLM and Browser chats accept PNG/JPG directly!
param([switch]$Configure)
$ErrorActionPreference='Stop'
$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
$conf=Join-Path $Root 'config.json'
if(-not(Test-Path $conf)){throw 'Missing config.json. Run INSTALL.cmd first.'}
$c=Get-Content -LiteralPath $conf -Raw -Encoding UTF8 | ConvertFrom-Json
$Alias=[string]$c.modelAlias
$Model=[string]$c.model
$Ctx=if(($c.PSObject.Properties.Name -contains 'contextSize') -and ([int]$c.contextSize -ge 2048)){[int]$c.contextSize}else{4096}
$MaxTok=if($Ctx -ge 4096){'1024'}else{'512'}
$PublicPort=8080
$BackendPort=8081
$PublicUrl="http://127.0.0.1:$PublicPort"
$BackendUrl="http://127.0.0.1:$BackendPort"
$BridgeScript=Join-Path $Root 'BgGPT-OCR-Bridge.ps1'
$Logs=Join-Path $Root 'logs'
New-Item -ItemType Directory -Path $Logs -Force | Out-Null

function Model-ReadyAt([string]$baseUrl) {
  try{
    $res=Invoke-RestMethod -Uri "$baseUrl/v1/models" -TimeoutSec 2
    return @($res.data|Where-Object {([string]$_.id).EndsWith($Alias,[StringComparison]::OrdinalIgnoreCase)}).Count -gt 0
  }catch{return $false}
}

function Bridge-Ready {
  try{
    $r=Invoke-RestMethod -Uri "$PublicUrl/ocr-bridge/health" -TimeoutSec 2
    return ($r.status -eq 'ok' -and $r.bridge -eq 'bggpt-ocr-proxy')
  }catch{return $false}
}

function Port-Listening([int]$port) {
  $conns=@(Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue)
  return ($conns.Count -gt 0)
}

function Stop-OwnProcessOnPort([int]$port,[bool]$allowBridge) {
  $ids=@(Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique)
  if(-not $ids.Count){return}
  $allowedServers=@((Join-Path ([string]$c.runtime) 'llama-server.exe'),(Join-Path ([string]$c.cpuRuntime) 'llama-server.exe'))
  foreach($idVal in $ids){
    $p=Get-CimInstance Win32_Process -Filter "ProcessId=$idVal" -ErrorAction SilentlyContinue
    if(-not $p){throw "Port $port is occupied by an unverified process."}
    $exe=[string]$p.ExecutablePath
    $cmd=[string]$p.CommandLine
    $isOwnLlama=($allowedServers -contains $exe) -and ($cmd.IndexOf($Model,[StringComparison]::OrdinalIgnoreCase) -ge 0)
    $isOwnBridge=$allowBridge -and ($cmd.IndexOf('BgGPT-OCR-Bridge.ps1',[StringComparison]::OrdinalIgnoreCase) -ge 0)
    if(-not $isOwnLlama -and -not $isOwnBridge){
      throw "Port $port belongs to another application ($exe). Close it before starting BgGPT."
    }
  }
  foreach($idVal in $ids){Stop-Process -Id $idVal -Force -ErrorAction SilentlyContinue}
  Start-Sleep -Seconds 2
}

function Start-Backend([string]$path,[bool]$useGPU,[bool]$legacy) {
  $server=Join-Path $path 'llama-server.exe'
  if(-not(Test-Path $server)){throw ('Missing runtime: '+$server)}
  if($legacy){
    $env:GGML_VK_DISABLE_F16='1'
    $env:GGML_VK_DISABLE_ASYNC='1'
  } else {
    Remove-Item Env:GGML_VK_DISABLE_F16 -ErrorAction SilentlyContinue
    Remove-Item Env:GGML_VK_DISABLE_ASYNC -ErrorAction SilentlyContinue
  }
  $offload=if($useGPU){'99'}else{'0'}
  $args='-m "'+$Model+'" --alias "'+$Alias+'" -ngl '+$offload+' -c '+$Ctx+' --host 127.0.0.1 --port '+$BackendPort
  if($legacy){$args+=' -fa off'}
  $stdout=Join-Path $Logs 'server-out.log'
  $stderr=Join-Path $Logs 'server-error.log'
  foreach($f in @($stdout,$stderr)){if(Test-Path $f){Remove-Item $f -Force}}
  $proc=Start-Process -FilePath $server -ArgumentList $args -WorkingDirectory $path -WindowStyle Minimized -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru
  for($i=0;$i -lt 75;$i++){
    Start-Sleep -Milliseconds 700
    if(Model-ReadyAt $BackendUrl){return $true}
    $proc.Refresh()
    if($proc.HasExited){break}
  }
  if(-not $proc.HasExited){Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue}
  return $false
}

function Start-OcrBridge {
  if(-not(Test-Path -LiteralPath $BridgeScript)){throw 'Missing BgGPT-OCR-Bridge.ps1. Run INSTALL.cmd again.'}
  $bArgs='-NoProfile -ExecutionPolicy Bypass -File "'+$BridgeScript+'" -ListenPort '+$PublicPort+' -UpstreamPort '+$BackendPort
  $proc=Start-Process -FilePath 'powershell.exe' -ArgumentList $bArgs -WorkingDirectory $Root -WindowStyle Minimized -PassThru
  for($i=0;$i -lt 45;$i++){
    Start-Sleep -Milliseconds 400
    if(Bridge-Ready){return $true}
    $proc.Refresh()
    if($proc.HasExited){break}
  }
  if(-not $proc.HasExited){Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue}
  return $false
}

try{
  if(-not (Test-Path $Model)){throw 'Model missing. Run INSTALL.cmd again.'}

  # 1. If an older direct llama-server (v11 / v12-Fast / Vision) occupies port 8080, stop it to place OCR Bridge on 8080
  if((Port-Listening $PublicPort) -and (-not(Bridge-Ready))){
    Write-Host 'Upgrading port 8080 to Auto OCR Bridge... / Освобождаване на порт 8080 за OCR моста...' -ForegroundColor Yellow
    Stop-OwnProcessOnPort $PublicPort $true
  }

  # 2. Ensure fast llama-server.exe is running on internal port 8081
  if(-not(Model-ReadyAt $BackendUrl)){
    if(Port-Listening $BackendPort){Stop-OwnProcessOnPort $BackendPort $false}
    Write-Host ('Starting fast BgGPT engine on port '+$BackendPort+' ('+$c.backend+', ctx '+$Ctx+')...')
    $isGPU=([string]$c.backend -ne 'cpu')
    $ok=$false
    try{$ok=Start-Backend ([string]$c.runtime) $isGPU ([bool]$c.legacyAmd)}
    catch{Write-Warning ('GPU start failed: '+$_.Exception.Message); if(-not $isGPU){throw}}
    if(-not $ok -and $isGPU){
      Write-Warning 'GPU runtime failed to start. Trying safe CPU fallback / Опит с CPU.'
      $ok=Start-Backend ([string]$c.cpuRuntime) $false $false
    }
    if(-not $ok){throw ('BgGPT engine did not become ready on port 8081; see '+(Join-Path $Logs 'server-error.log'))}
  }

  # 3. Ensure Offline Windows OCR Bridge is running on public port 8080
  if(-not(Bridge-Ready)){
    Write-Host ('Starting Offline Windows OCR Bridge on port '+$PublicPort+'...')
    $bOk=Start-OcrBridge
    if(-not $bOk){throw ('OCR Bridge did not become ready on port 8080; see '+(Join-Path $Logs 'ocr-bridge.log'))}
  }

  if(-not(Model-ReadyAt $PublicUrl)){
    throw 'OCR Bridge started but model endpoint on 8080 did not respond. See logs\ocr-bridge.log.'
  }

  Write-Host '[OK] Local BgGPT + Auto OCR Bridge is ready / BgGPT с автоматичен OCR мост е готов.' -ForegroundColor Green
  Start-Process $PublicUrl | Out-Null

  $anything=[string]$c.anything
  if($anything -and (Test-Path $anything)) {
    Start-Process -FilePath $anything | Out-Null
    if($Configure){
      Start-Sleep -Seconds 3
      $pair=@{
        type='llm'; provider='generic-openai';
        GenericOpenAiBasePath='http://127.0.0.1:8080/v1'; GenericOpenAiKey='local-only';
        GenericOpenAiModelPref=$Alias; GenericOpenAiTokenLimit=[string]$Ctx; GenericOpenAiMaxTokens=$MaxTok
      }
      $keys=@('type','provider','GenericOpenAiBasePath','GenericOpenAiKey','GenericOpenAiModelPref','GenericOpenAiTokenLimit','GenericOpenAiMaxTokens')
      $query=($keys | ForEach-Object { $_+'='+[uri]::EscapeDataString([string]$pair[$_]) }) -join '&'
      try{Start-Process ('anythingllm://set-provider?'+$query) | Out-Null}
      catch{Write-Warning 'Open CONFIGURATION-BG-EN.txt to connect AnythingLLM manually.'}
      Write-Host 'Confirm with Use inside AnythingLLM / Потвърдете с Use.' -ForegroundColor Yellow
    }
  }
  Write-Host "Local API (with Auto Image OCR) / Локален API: $PublicUrl/v1"
}catch{
  Write-Host ('ERROR / ГРЕШКА: '+$_.Exception.Message) -ForegroundColor Red
  exit 1
}
